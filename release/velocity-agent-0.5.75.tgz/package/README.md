# Velocity agent

Local workers for pending Velocity agent runs. This is separate from the general Velocity management CLI.

Requires Node 18.20 or newer. Install the compiled package from Velocity's public GitHub release:

```sh
npm install --global https://github.com/velocity-quest/velocity-agent/releases/download/agent-v0.5.75/velocity-agent-0.5.75.tgz
velocity-agent --version
```

After an upgrade, let active runs finish and restart the worker. An existing
process continues using the code it loaded at startup, and its heartbeat keeps
reporting that running version; `velocity-agent --version` only shows what is
installed on your PATH.

From 0.5.57, a running worker also checks the package its own launch path
resolves to. When that installation has a different version, the terminal and
the Agents page show both versions, and how a minimum-version policy affects
the old one. Select **Restart when idle** on the Agents page, or run
`kill -USR2 <pid>` on the host (only for 0.5.57 or later: an older worker does
not handle that signal and stops immediately). The worker then claims no new work, lets the
current run finish, and replaces itself in place: same PID, command line, CLI
options, environment, sign-in and saved worker slot. Worktrees, queued work and
delivery records are not touched, and a sibling worker on the same host or
repository is unaffected. The update notice clears only when the replacement's
own heartbeat reports the new version. If the restart cannot run (Windows, a
Node.js release older than 22.15, an unreadable installation or a failed
`execve`), the original process keeps running and claiming work, and reports why.
A replacement that never reports back appears as **Restart did not complete**;
start the worker again with the same command.

If 0.5.18 reports
“This execution has no authenticated local connection” before claiming queued
work, upgrade to 0.5.19 and restart; the fix preserves the existing Velocity sign-in.

The package is distributed through GitHub releases, not the npm registry. Product CI builds and checks the package, then distribution CI publishes it with a SHA-256 checksum on an `agent-vVERSION` tag. The product repository and its workspace package remain private; the public distribution contains only the compiled package and release materials.

Release installation checks exercise both prefix and global npm installs, verify the identified dependency tree, compare native package bytes and run the installed Codex and Claude version commands without sign-in or model requests.

Maintainers relay a successful main **Agent CLI** workflow artifact with `node packages/agent/scripts/release-from-ci.mjs RUN_ID ENGIN-ISSUE_NUMBER` from the exact checked commit, using their existing GitHub sign-in. Before downloading the archive or writing anything public, the relay lists the distribution repository's `agent-v*` tags and `release/agent-v*` candidate branches and refuses a version that is already published, already staged or older than the newest of them, naming the next unused version to set in `packages/agent/package.json`. The relay stages that checksummed archive on a new immutable `release/agent-vVERSION` branch in the public distribution repository. It never uploads a locally built package, overwrites a candidate or publishes a release; distribution CI verifies the artifact and its branch/version identity, checks clean installs and publishes it. This avoids dispatch payload size limits and needs no registry credential or cross-repository CI secret.

For a trusted main release, maintainers can run the same workflow on temporary Linux x64 self-hosted runners labeled `velocity-agent-release`: `gh workflow run agent.yml --ref main -f runner=self-hosted`. Repository administrators must register the runners, keep them available for the package job and both Node installation jobs, and remove their registration and work directories afterward. Ephemeral runners accept one job each. PRs, pushes and dispatches of other refs always use GitHub-hosted runners. Both routes require every check and the verified artifact to succeed before relaying a release; this option does not change account billing or publish a locally built package.

Version 0.5 adds multiple workspace consent. Sign in again to expand an existing single-workspace grant; refresh never adds access automatically. Removed memberships stop working immediately.

Sign in to Velocity and select every workspace you want to authorize in your browser:

```sh
velocity-agent login
velocity-agent whoami
velocity-agent status
velocity-agent run
```

Each worker keeps a saved identity and its website settings across restarts.
Normal `run` commands reuse a free saved worker for the same account, workspace,
team, runtime and checkout. Concurrent processes get separate workers. Restarting
in the same supported terminal prefers that terminal's previous worker.

To choose a particular locally saved worker, use its name or Worker ID from the
Agents page: `velocity-agent run --worker "Worker 2"`. A new name creates a named
worker. Keep the private `agent-machine.json` and `workers/` identity state under
`~/.config/velocity` (or `$XDG_CONFIG_HOME/velocity`) to preserve registration. The
public Worker ID alone cannot restore lost local state. A copied machine or reset
server can require a new paused registration; review its settings before starting.
Changing explicit team,
runtime or checkout options selects a different automatic worker, unless you pin
one with `--worker`. CLI options still override website settings.

A process restart creates a new session for that saved worker. Run history keeps
its original session association. The Agents page shows the current session once;
older registrations remain available under Previous sessions.

Diagnose a local installation without changing configuration, credentials or worker state:

```sh
velocity-agent doctor
velocity-agent doctor --workspace my-workspace --repo /path/to/checkout
velocity-agent doctor --workflow /private/workflow.json --json
```

Doctor prints `PASS`, `WARN`, `FAIL` or `UNAVAILABLE` for every check, with context
and suggested next steps. It exits **1** for detected failures and **0** for
success, warnings or unavailable checks alone. `--json` returns the same checks
and an `exitCode`. It uses the normal `--base-url`, `--api-key`,
`VELOCITY_MCP_TOKEN` (or legacy `VELOCITY_API_KEY`) and `VELOCITY_WORKSPACE`
selection. Prefer environment variables for private keys.

Checks include Node/Git, local credential and repository-link validity and
permissions, credential-lock presence, optional workflow/checkout configuration,
Velocity identity and authorized workspaces, and detected supported agent CLIs.
Available Velocity statistics are daily UTC first-claim counts, including failed
runs; limits reached and emergency stop appear as warnings. Statistics can be
unavailable on older servers or with insufficient scopes/plans. Use `--workspace`
to inspect one workspace; otherwise usage rows follow the authorized workspace
order as Workspace 1, Workspace 2, and so on.

Codex, Claude Code and Cursor sign-in are inspected with their status commands.
Grok Build, Muse Code and Antigravity sign-in, and provider account quota/spend/token
totals, are explicitly unavailable when no safe status probe exists. A reported
sign-in does not verify provider entitlement or key validity. An optional
Anthropic API key is checked for presence only. No model calls, provider sessions,
login, credential refresh, repair or workflow commands are started. Expired
Velocity access tokens are reported with guidance to refresh using `whoami`
outside doctor. Raw credential contents and native/server diagnostics are never printed.

Login opens a browser and listens on an ephemeral 127.0.0.1 port. If the browser cannot reach that port, paste the full redirected URL into the terminal. For SSH, containers, or a browser on another machine, use `velocity-agent login --no-browser` and paste the value shown on Velocity's code page. SSH sessions automatically use this flow. Terminal input is hidden, and login expires after five minutes.

Saved credentials authorize exactly the selected workspace set. `run` and `status` process all currently authorized workspaces by default; `--workspace <id-or-slug>` focuses on one. They use saved sign-ins without a key, refresh automatically, and serialize refresh across CLI processes. Tokens are stored per server origin in `$XDG_CONFIG_HOME/velocity/credentials.json` (default `~/.config/velocity/credentials.json`) with mode 0600. `velocity-agent logout` revokes that server's grant and removes its entry; other server entries are preserved. Use the same `--base-url` for login, run, whoami, and logout on another instance.

Concurrent commands retry if a credential-lock owner releases or replaces its
lock during the ownership check. A genuinely abandoned credential lock requires
explicit recovery: close other Velocity commands, remove only the lock path
shown in the error, then retry. Locks are never reclaimed automatically.

For automation, create a workspace token in **Settings → MCP**, with `mcp:read` and `mcp:write`, and set `VELOCITY_MCP_TOKEN` privately. The legacy `VELOCITY_API_KEY` variable also works. An explicit key takes precedence over browser credentials. `--workspace` or `VELOCITY_WORKSPACE` is optional; if supplied it must be among the currently authorized workspaces. Keep tokens out of repository files.

## Complete work that needs no new source changes

Worker 0.5.42 streams long Claude Code runs without a cumulative output cap. It limits each event to 2 MB and pending tool state to 1,024 tools and 8 MB; malformed or oversized events, cancellation and execution timeouts still stop the run. The release also redacts supported workspace and personal API key formats from diagnostics without requiring local secret registration.

Worker 0.5.40 can reuse an earlier accepted native delivery for the same unchanged issue and exact base source. It rechecks the merged PR’s current checks and required reviews, then runs the pinned acceptance verifier when deployment is required. It creates no new commit, PR or deployment. Current authorization and workspace limits still apply.

When automatic proof is unavailable, the run remains blocked with `DELIVERY_NO_CHANGES`. Open **Review existing work** on that run, select an earlier delivery or link the existing PR in **Delivery continuations**, and run the command shown from the linked repository on the original worker host:

```sh
velocity-agent workflow verify-existing --workspace WORKSPACE --run RUN_ID --reference REFERENCE_ID --reference-kind run
```

Use `--reference-kind pull_request` for a linked PR. Add `--repo /path/to/checkout` when outside the repository. If the original run used a private workflow, supply the same `--workflow /private/workflow.json`; its command digest must match. The command locks the preserved owned task worktree, reruns validation and only the acceptance verifier, then records fresh proof. It never starts a model, commits, pushes or deploys.

The original requester must explicitly confirm acceptance in the browser within 15 minutes of verification. The issue transition and one completion comment are committed together. The original coding execution, outcome and no-change handoff remain in history, with links to the actual delivery. Changed requirements, assignment, pinned policy, current authority or minimum worker version require review or a new authorized attempt; model prose or an artifact URL alone cannot complete an issue. This flow supports merge and deployment workflows; local and PR handoffs keep their existing stopping behavior.

## Start now, select execution on the website

Worker 0.5.25 adds direct Agents-page repair, field sources and acknowledged configuration revisions. Install the verified release linked above.

After login, run `velocity-agent run` or `velocity-agent run --workspace YOUR_WORKSPACE`. No provider key, executor, model, effort, team or repository option is required to connect. Open **Agents → Local workers**, select **Fix setup** or **Configure** on this worker, choose its runtime and context, then **Save and start**. The same editor is available in **Settings → Agents → Workers**. No selection, no command or multiple detected runtimes leave the worker connected and waiting. The provider integration must still be enabled for assignments to queue.

Discovery checks Claude Code and the exact Codex runtime used by the adapter with bounded version and read-only authentication probes. The bundled Codex runtime counts as installed; it still needs your native sign-in. An executable with missing/unverified authentication is installed but unavailable. Muse is inventoried as unsupported, with no execution capabilities. Discovery never invokes login or inference, reads provider secret files or uploads raw diagnostics, account identifiers or local paths. Configured authentication does not prove model entitlement or full adapter compatibility; native catalog checks still run before claim.

Only **Anthropic API** execution requires `ANTHROPIC_API_KEY` or `--anthropic-key` locally. Selecting Claude Code or Codex uses that runtime's existing authentication. Missing authentication, unavailable executors, incompatible model/effort settings and missing repository links leave queued work pending and show a waiting reason. Correct settings or sign in with the runtime's own CLI; discovery retries every minute.

Managed Codex runs use a fresh, execution-scoped Velocity MCP connection. The worker inspects the native configuration before coding, disables inherited MCP servers, apps and plugins for that process, and binds the allowed tools to the current workspace and execution. Model and sign-in preferences are preserved. These overrides leave your global tool settings in place; the native runtime can still record normal project and session metadata. A runtime that cannot provide the required configuration inspection stops before starting a coding turn.

Worker 0.5.67 also checks the authenticated tool catalogue and reads the current issue through the same execution-bound connection before Codex starts coding. Missing required tools, denied issue access and connection failures stop before model work. Both Codex and Claude transports send the actual worker version, so supported outcomes are recognized while the server continues to enforce current sign-in, scopes and lease ownership.

The website shows each field's source. **CLI option** fields are locked and display the explicit value even when setup is incomplete; remove that option when restarting to give the website control. Explicit CLI options always override saved preferences, including explicit false options. Omitted options never select Claude/Anthropic implicitly. `--agent codex` selects native Codex; `--agent claude` selects Claude Code unless an explicit `--executor` accompanies it. `--no-allow-delivery` overrides website push/PR authorization; `--no-single-checkout` requires task worktrees. A local `--workflow` controls delivery instead of website PR handoff. Existing shared policy can restrict these choices.

Worker 0.5.40 reports the selected delivery stop and its source in normal startup output and in **Worker details → Selected delivery stop**. A loaded workflow can select local work, a PR, merge, or deployment independently of the separate push/PR handoff option. This is a reported selection: current issue requirements, enabled saved profiles and protected workspace limits are checked for each run.

Saved settings remain pending until the worker checks and acknowledges their revision. **Needs attention** includes specific setup actions, such as selecting a team or signing in locally. During a task, the summary retains the active configuration; changed settings apply after that task, before another claim. Idle workers pick up changes on their next poll without restarting. Offline workers cannot acknowledge changes until reconnected. A conflicting save preserves your edits; **Reload settings** fetches the current revision for review. Older workers that do not report applied revisions show **not reported**; update the worker to obtain acknowledgement.

The editor can select among this machine's declared repository links, but it cannot discover an arbitrary private checkout or create runtime credentials. Run `velocity-agent repo link` once for a new checkout. Your **Delivery profile settings** are available inside your own worker editor; shared defaults and protected limits retain their existing workspace permissions. Deployment/check adapters still require a private profile-enabled host workflow; a saved delivery preference cannot create missing adapters.

A private random machine ID is stored alongside credentials as `agent-machine.json`; each process gets a separate session ID. Website selections survive restart for that machine, workspace, owner and grant. Every approved workspace registers separately, including grants with `accountAccess: false`. Members can view/configure their own workers; owners/admins can manage workspace workers. Heartbeats run every 15 seconds, inventory refreshes every minute, and 90 seconds without contact displays offline. Failed requests use bounded reconnect backoff up to 30 seconds; no work is claimed without a fresh session/configuration read. Settings edits and Start/Pause/Stop apply at the next task boundary. Existing queues and atomic run leases still own assignment; this does not schedule unassigned issues.

An older server without `/api/agent/sessions` leaves this worker waiting. Deploy the session migration and API/UI before installing the new worker. `--once` registers and performs one configured batch; waiting for website selection exits successfully, while an unavailable selected runtime or failed connection exits unsuccessfully with queued work preserved.

## Link a repository once

First configure an unambiguous **Repo → Team** or **Repo → Project** mapping under **Settings → Integrations → GitHub**. A project mapping takes precedence. Then authenticate and link its local checkout:

```sh
velocity-agent repo link --workspace your-workspace --team YOUR_TEAM --repo /path/to/repository
velocity-agent repo list --workspace your-workspace
velocity-agent run --workspace your-workspace
# On Agents, choose Fix setup, Codex or Claude Code, the team and Save and start.
```

Add `--project PROJECT_UUID` when linking a project-specific repository. The link command verifies workspace/team/project access, the server's current GitHub mapping and default branch, the local `origin` identity and local Git fetch access. It does not switch branches or stash/reset your changes. Native workers recheck the mapping before claim and delivery; a moved issue or remapped repository requires relinking. Git diagnostics and credentials are never copied to Velocity.

The options select different things:

| Option or setting | Example | Meaning |
| --- | --- | --- |
| `--workspace` | `velocity-project` | An authorized Velocity workspace slug or UUID |
| `--team` | `ENGIN` | A team identifier or UUID within that workspace |
| `--repo` | `~/projects/velocity/velocity` | A local Git checkout directory on this machine |
| GitHub team/project mapping | `velocity-quest/velocity` | The GitHub `org/repo` configured in Velocity, checked against local `origin` |

`--repo velocity-project/engin` and `--repo velocity-quest/velocity` are treated as relative filesystem paths, not remote identifiers. Directory names never choose an account, authorize a workspace or infer a team. If `~/projects/velocity` is a wrapper containing the actual checkout at `~/projects/velocity/velocity`, select the inner directory. Quote paths containing spaces; an unquoted leading `~` is expanded by your shell.

`repo list` lists only saved links on this machine for the selected server and currently authorized workspaces. An empty `[]` means no matching saved links; it does not mean GitHub has no repositories. Run `repo link` for the intended checkout and workspace/team. `repo tasks` instead lists owned local task checkouts for that Git repository and authorized workspaces; it does not list the remote issue queue. An empty task list means no matching task manifests exist locally.

`repo link` and `repo tasks` accept the current directory by default, including a subdirectory of a checkout or an owned worktree. These commands work inside the checkout:

```sh
cd ~/projects/velocity/velocity
velocity-agent repo link --workspace velocity-project --team ENGIN
velocity-agent repo tasks --workspace velocity-project
# From anywhere, explicit selection still works:
velocity-agent repo link --workspace velocity-project --team ENGIN --repo ~/projects/velocity/velocity
```

Both commands check the local path before sign-in or server repository selection; linking also requires a GitHub `origin`. Missing paths and wrapper/non-Git directories explain how to select `--repo /path/to/checkout`. Absent and non-GitHub origins have separate guidance. A mapping mismatch requires the intended checkout or a corrected authorized mapping; it never fetches the mismatched remote. Git authentication/access failures ask you to authenticate Git locally and confirm read access; Velocity browser login does not authenticate Git. Other fetch failures point to network access and the configured base branch. Messages discard raw remote URLs, credential-helper diagnostics and Git stderr.

Links are local, private and scoped to server/workspace/team/project in `$XDG_CONFIG_HOME/velocity/agent-repositories.json`. A multi-workspace worker resolves each issue separately; it does not reuse another workspace's checkout. `--repo` is an explicit checkout override; Ordinary GitHub checkouts must still match the issue mapping. LandingBoost fixes use their separately verified page/repository grant; an explicit `--repo` may select that approved page checkout even when the general GitHub mapping points elsewhere. A local repository without a GitHub origin can be used explicitly for local work, with delivery disabled.

Ordinary linking leaves repository instructions untouched. Add `--write-context` only when you want the setup command to append the verified workspace context to `VELOCITY.md` and a small reference to `AGENTS.md`. Existing text is preserved and repeated matching setup adds no duplicate section. Links, context and task manifests contain no provider keys or account tokens.

## Task worktrees and recovery

Worker 0.5.5 uses writable worktrees by default. Code lives under `$XDG_DATA_HOME/velocity-agent/worktrees` (default `~/.local/share/velocity-agent/worktrees`), outside protected Git metadata. The original Git common directory holds the ownership manifests and task locks in `velocity-agent-tasks`. Each manifest binds server, workspace, issue and run to the repository identity, branch, base commit and exact path. GitHub branch templates are reused with a unique task suffix. Worktrees start from the verified repository default-branch commit; explicit local-only repositories start from HEAD. Install project dependencies in the task checkout when needed; dependencies and private environment files are not copied automatically.

When a native implementation is complete but its required checks cannot run inside the model sandbox (Docker, database or browser checks, or commands that need approval), worker 0.5.52 and later let the model report `ready_for_validation` instead of claiming success or ending as partial work. The server accepts that outcome only while this run's prepared host workflow requires validation. The host then rechecks the claim, ownership, pinned check digest, repository identity and source tree, and runs only its configured checks; passing checks continue the usual PR, CI, merge and deployment stages. A check that fails or cannot start on the host stops with `VALIDATION_FAILED` or `VALIDATION_COULD_NOT_START` and keeps the changes for bounded repair or manual action. A handoff that never reaches host registration stops with `HOST_VALIDATION_UNAVAILABLE`. None of these close the issue, and without a configured workflow the worker never pushes such work.

A failed or interrupted task keeps its branch, commits and diff. The source checkout stays on its original branch. Use `repo resume` with worker 0.5.51 or later and the original connection to create an authorized successor using that checkout; terminal runs are never reset. List saved task identities first:

```sh
velocity-agent repo tasks --workspace your-workspace --repo /path/to/repository
velocity-agent repo resume --workspace your-workspace --repo /path/to/repository --run RUN_UUID
velocity-agent repo recover --workspace your-workspace --repo /path/to/repository --issue ISSUE_UUID --run RUN_UUID
velocity-agent repo cleanup --workspace your-workspace --repo /path/to/repository --issue ISSUE_UUID --run RUN_UUID
```

Use `recover` only after stopping the worker. It checks that the recorded PID is dead and releases only that same task lock; live, replaced or invalid locks are refused. `cleanup` removes only a clean inactive registered worktree with matching ownership. Modified, untracked or ignored files and foreign paths/branches are refused. Preserve such files yourself before cleanup. Branches and commits remain for review/recovery; cleanup never force-removes or deletes a branch. An explicitly selected `--single-checkout` keeps the older writable-checkout mode, requires a clean source and serializes workers with the common `.git/velocity-agent.lock`. Never remove that lock until its worker is confirmed stopped. Keep `XDG_DATA_HOME` consistent for task resume/cleanup.

### Temporary storage and validation

Native attempts, host validation and built-in Vercel operations use private
temporary directories. On Linux the default volume is
`$XDG_DATA_HOME/velocity-agent/tmp`, or `~/.local/share/velocity-agent/tmp`
when XDG_DATA_HOME is unset. An explicit host TMPDIR (or TMP/TEMP) takes
precedence. Each attempt receives its own TMPDIR and Node compile-cache path;
account configuration, sign-in files and other configured caches stay in place.

The worker checks writable space and free inodes before claiming native work.
Low capacity leaves work queued and appears as temporary storage needing
attention on the Agents page. Polling checks again automatically. NORMAL output
also explains byte/inode exhaustion reported by failed commands. Check both
`df -h` and `df -i` for the affected volume: free bytes do not imply free inodes.
To choose another volume, restart with
`TMPDIR=/path/to/disk-scratch velocity-agent run` and your normal options.

External daemons do not inherit the validation command's TMPDIR. When Docker
reports that daemon temporary staging has run out of space, delivery retains
the validation checkpoint and retries on a later poll without a coding repair.
The diagnostic names the reported directory and, when available, local host
bytes and inodes; a remote or isolated daemon may see a different filesystem.
Check both measures on the daemon host and free only confirmed inactive scratch.
The worker does not prune daemon data or change its configuration.

An attempt removes only its own scratch directory after success, failure or
normal cancellation. On Linux and macOS, interrupted validation stops its command group before
removing scratch; the repository and preserved task worktree remain available.
Commands that explicitly write elsewhere own those files themselves. A hard
process or machine kill can leave scratch behind. Verify that the attempt and
its child processes have stopped before manually removing that directory.
The worker never sweeps shared /tmp, guesses ownership from a directory's age,
or deletes another worker's files.

### Provider quota, sign-in and network holds

A native CLI that exits because its sign-in hit a usage or rate limit, is signed
out, or lost its connection is classified before anything is recorded. The run
is marked failed with a fixed description such as "Claude Code sign-in reached
its usage or rate limit (resets 2026-10-29 10:30 UTC)"; the provider's own text
never reaches Velocity. Only the attempted issue gets that record. The worker
then writes a hold to `$XDG_DATA_HOME/velocity-agent/provider-holds.json`
(`~/.local/share/velocity-agent/provider-holds.json` by default) keyed by a hash
of the executor, binary, configuration home and credential source, so every
worker process and workspace on the machine that shares the sign-in stops
claiming. Queued issues stay assigned and unclaimed; the attempted task's
partial changes stay in its worktree. A model-access failure fails only its
run, because other issues may use an available model.

The hold is bounded: quota holds last until the reported reset plus a minute,
or 30 minutes doubling to 6 hours without a trustworthy reset; sign-in holds
start at 10 minutes and network holds at 2 minutes, doubling while the problem
persists. The Agents page shows the worker as **Provider hold** with the
failure, reset and automatic retry times and a **Retry provider now** action.
That action saves the worker settings with Start; the revision change releases
the hold, and the next claim rechecks authorization, shared policy, CLI
overrides and issue ownership before any work starts. From the terminal:

```sh
velocity-agent provider holds
velocity-agent provider retry claude-code   # or codex; omit to release every hold
```

The hold file carries no credentials, paths or provider output. Workers on
other machines using the same account are not coordinated.

## Shared workspace controls

Worker 0.5.7 reads **Settings → Agents → Loops** at startup and immediately before each claim. Emergency stop and a different provider or hosted execution preference leave this local worker waiting, without claiming or failing queued work. Disabling shared controls preserves the existing provider configuration; it does not requeue stopped runs. The runner never switches providers, models or billing methods automatically.

Each authorized workspace has a separate settings snapshot and journal cursor. The host checks committed policy invalidations at five-second heartbeat/safe boundaries, rereads after an expired cursor or journal failure, and refreshes settings at least every 30 seconds while polling. The queue interval is capped at 30 seconds; requests have a 10-second deadline. Unreadable, revoked or incompatible controls stop new work; an active task is interrupted and its changes remain available for recovery. Before commit, delivery or a final result, controls are read again. The server still enforces current scope, concurrency, integration permissions and cancellation atomically.

The configured server must support `get_agent_loop_settings`. An older server without it cannot authorize new work with this worker; update the server. Maintenance calls stay in the host and do not expose settings updates or the event journal as model tools. Existing repository links, native model/effort defaults and delivery authorization remain separate. Worker 0.5.19 also registers live runtime sessions; the full scheduler remains separate.

Before taking new queued work, the server selects eligible runs on In Progress issues already assigned to the same agent. Pending owned work comes first; already leased work stays with its owning worker and preserves configured concurrency. Native workers remain scoped to their selected team and executor. Todo-only selection governs new work and permits an existing queued assignment to continue its agent's In Progress issue. Explicit status allowlists and all other workspace/provider restrictions still apply. New work stays pending while yielding. This is server-side behavior, so existing workers need no upgrade.

Assign an issue to Codex/Claude or mention the agent to queue it; moving an unassigned issue to Todo does not queue it automatically. Blocked, review, waiting and terminal issues are skipped. Polling never restarts a failed/cancelled/completed attempt; use `repo resume` for eligible failed native work after reviewing the cause and current ownership.

Worker 0.5.17 explains idle queues and expected claim contention at normal verbosity. Shared workspace and provider concurrency limits both apply: a provider limit of two cannot override a shared Loops limit of one. Waiting output identifies the limiting setting and points to Settings → Agents; unchanged notices repeat at most once a minute. Another worker's lease is skipped without failing its run, and other eligible work continues. Genuine preflight errors remain visible, leave unclaimed work pending, and make a one-shot invocation unsuccessful.

Normal verbosity identifies each native command/tool as it starts and completes, with its exit status when reported and a bounded reason for failure. Successful output and detailed failure logs require FULL. The agent can recover and continue. Credentials and terminal controls are removed before display. QUIET suppresses step details, while FULL retains detailed diagnostics. Command failures also save redacted diagnostics in the task event, independently of console verbosity.

## Queue loops (worker 0.5.60)

```sh
velocity-agent loop --once                 # drain eligible work, then exit
velocity-agent loop --watch                # keep running; wake on workspace events
velocity-agent loop --once --resume <uuid> # continue an interrupted loop's record
```

`loop` is the same worker as `run`: it accepts the same options, uses your saved sign-in, website configuration, repository links, provider and delivery settings, and claims through the same server selection, atomic claims, leases, heartbeats and execution fences. There is no second scheduler, and local and cloud workers cannot both claim one run. `run --once` keeps its single-batch behavior.

- **Selection.** The server orders eligible work by the workspace's published priority order (default Urgent, High, Medium, Low, None), then due date, issue age and a stable run ID. The loop selects again after every claimed task, so a raised priority, a new assignment or a changed setting takes effect before the next claim instead of a cached batch being consumed.
- **Skipped issues.** Issues in review, blocked, waiting for feedback, completed or cancelled are never claimed. Shared Loops controls exclude them on the server; without enabled controls the loop checks the issue status before claiming. Each skip is reported once, and the run stays queued untouched.
- **`--once`** exits after a fresh selection finds no actionable work. Exit status 0 means the drain completed, the loop is waiting on capacity, a quota or pending delivery, or the worker is paused/stopped on the Agents page; the final line names which. Missing setup (repository link, provider sign-in, runtime), an unavailable workflow, a provider hold or a connection problem exits non-zero with the diagnostic and claims nothing. Queued work behind capacity, a daily quota or pending delivery leaves the loop **waiting**. A failed attempt does not stop other compatible work; the drain then ends **failed**. Failed runs are never retried automatically.
- **`--watch`** waits when idle. Issue and comment events (assignment, priority, status, mentions) wake it within about five seconds, and Agents-page Start, Pause or settings changes within about 15 seconds; it also selects again at least every 30 seconds (`--poll-interval`, minimum 30000 for loops). The event feed only invalidates a selection and its text is never used as instructions. Pause or Stop on the Agents page and emergency stop in **Settings → Agents → Loops** prevent new claims; the loop keeps waiting until Start.

The loop prints its UUID and a private progress file under `${XDG_STATE_HOME:-~/.local/state}/velocity/loops/`. The file records running, waiting, paused, stopped, completed or failed, pass and claim counts, this and the previous worker session, the active run/execution and up to 100 recent run/execution references. It contains no credentials and is bound to the server, user and workspace set. `--resume <uuid>` on the same host continues the counts with a new worker session and reports a run that was active when the earlier process ended. Resuming never replays a provider turn or takes over an unexpired lease: the server's lease, provider session checkpoint (`velocity-agent session status --run <uuid>`) and repository delivery journal (`velocity-agent repo tasks`) stay authoritative. Only one live process can own a loop record. Loops do not restart in place; to load an update, stop the loop after its current run and resume it.

A completed loop means its drain ended, not that its issues are Done. Successful model text grants no completion authority: each issue closes only through its explicit outcome and the configured validation and delivery evidence. Commit, PR, merge, deployment and release limits are recorded on each run's host delivery record.

### Velocity loop skill

The package includes a portable skill at `skills/velocity-loop/SKILL.md` that runs this engine. Copy the `velocity-loop` directory into a host's skills directory, for example `~/.claude/skills/velocity-loop` for Claude Code (invoke `/velocity-loop`) or `~/.codex/skills/velocity-loop` for Codex (invoke `$velocity-loop`). Other hosts can load the file as instructions and use their own invocation syntax. Hosts that match skills by description also pick it up from requests such as "drain my Velocity agent queue". The skill contains no credentials and changes no sign-in, Start, repository access or delivery permission; it uses the authorization you already granted.

## Codex worker

Enable Codex under **Settings → Integrations → Codex**, then assign an issue to Codex or mention `@codex` in a comment. Sign in with `codex login`, or privately set your own `CODEX_API_KEY`.

```sh
velocity-agent status --agent codex --team YOUR_TEAM
velocity-agent run --agent codex --repo /path/to/repository --team YOUR_TEAM
```

The worker searches all teams in authorized workspaces when neither `--team` nor Velocity agent settings restrict the team. A configured team scope remains enforced, and an explicit `--team` overrides the worker’s website team selection. Add `--workspace your-workspace` to focus on one; without it, each approved workspace is polled in turn. Use a writable Git checkout with an initial commit and configured Git author. The default creates an owned writable worktree and task branch without changing the source checkout or its tracked, untracked or ignored files. Retried runs resume their saved branch and recoverable diff. Codex uses `workspace-write` with Velocity MCP tools and tests and edits code there. Issue text and comments are untrusted task data. The runner commits successful changes and links their real SHAs, then posts the final result as the Codex virtual member. Failed or stopped attempts cannot post a success result.

Worker 0.5.31 lets both Codex execution paths report outcomes through their
authorized Velocity MCP tools without an interactive approval prompt. There is
no Agents-page approval switch for this. If an older resumable worker says
`report_agent_outcome` requires approval while approvals are disabled, update
the worker and restart it. Shell escalation, unrelated MCP tools and interactive
approval requests remain unavailable. A separate delivery error such as
`CI_FAILED` must still be corrected before delivery can continue.

Delivery follows the selected host workflow and website settings, within workspace limits. With no delivery configured, commits stay local. `--allow-delivery` explicitly authorizes PR handoff and `--no-allow-delivery` explicitly keeps work local; CLI options override the website. A configured full workflow can also check, merge, deploy and close the issue after its required evidence passes. The model cannot perform those host-owned effects itself; restricted model Git tools do not mean host delivery is disabled. Native execution is unattended, bounded to 30 minutes and renews its lease; stale recovery fails abandoned work. Velocity's optional action checkpoint is unsupported for native workers and off by default.

Codex uses your own account and configured model/effort, without Velocity AI metering. `--model` and `--effort` are optional explicit overrides; omit both to preserve native defaults. `VELOCITY_CODEX_BIN` can select an installed compatible Codex binary. The package includes the Codex SDK's native runtime. One runner executes one task at a time; independent runners use separate owned worktrees. See recovery below for interrupted tasks.

Worker 0.5.8 checks an explicit Codex override against that exact execution
runtime's catalog before claiming a run or changing a checkout. An omitted
model or effort comes from the selected repository's native configuration (or
the runtime's default when unconfigured). The verified pair and provider carry
into the task worktree; the worker never silently changes to a different pair.
Unsupported choices or unavailable metadata leave queued work pending. Correct
the flags/native configuration and restart, or remove both overrides to use the
existing native default behavior.

```sh
velocity-agent codex models --repo /path/to/repository
```

This local command needs no Velocity sign-in and starts no thread or inference.
It displays model/effort/default metadata only, with `entitlementVerified: false`.
The runtime catalog may be cached and is not proof that your account can use a
model. Normal execution still handles provider authentication and access errors.
Catalog reads time out after 15 seconds and honor cancellation; older or custom
Codex binaries must support the read-only app-server config/model methods. The
0.5.11 candidate also resolves and pins default choices through this metadata
check, so removing overrides does not bypass an unavailable catalog.

## Claude Code worker

Install Claude Code, then sign in with `claude auth login`. The worker starts the installed CLI using its existing authentication; it does not obtain or proxy Claude subscription credentials.

```sh
VELOCITY_WORKSPACE=your-workspace velocity-agent run \
  --executor claude-code --repo /path/to/repository --team YOUR_TEAM
```

Enable Claude Code execution and select it as the desired execution method in Velocity. The worker selects pending issue runs across all teams in authorized workspaces, honoring any team scope in Velocity agent settings or an explicit `--team` restriction. It uses an owned writable worktree for each task, edits and runs checks there, and preserves the source checkout. The runner commits any remaining task edits, links the actual SHAs, and handles the effective host delivery workflow after rechecking the server lease, permissions and repository mapping. Configure delivery on the Agents page or use an explicit CLI override. Git/GitHub authentication must be available locally for delivery.

Native Claude Code does not implement Velocity's optional approval checkpoint. A workspace that requires that checkpoint cannot dispatch work to this worker; use the API executor for that policy. No checkpoint is required by default.

Worker 0.5.10 validates explicit `--model` and `--effort` choices before Git
fetches, claims or checkout changes. A listed alias resolves to one model ID,
and the same native executable, resolved model and optional effort are used for
execution and result attribution. Claude effort overrides require an explicit
model so the worker can verify the pair; omit both flags to retain native
configured defaults. Invalid choices, unavailable/old metadata and cancellation
leave work pending. Correct the flags or upgrade Claude Code and retry.
Advertised long-context suffixes such as `[1m]` are retained when resolving an alias.

```sh
velocity-agent claude models --repo /path/to/repository
velocity-agent run --executor claude-code --team YOUR_TEAM --model LISTED_MODEL --effort high
```

The local catalog command requires no Velocity sign-in and sends no user prompt
or inference request. It uses Claude Code's metadata-only SDK initialize
exchange, safe mode, disabled tools/hooks/MCP and no persistent session. Only
model IDs and supported efforts are displayed, with `entitlementVerified: false`;
account details and raw runtime diagnostics are discarded. The read has a
15-second deadline and honors cancellation. Catalog compatibility does not
guarantee provider access or quota. `VELOCITY_CLAUDE_BIN` selects the native
executable; otherwise it is resolved from PATH. Custom/older runtimes must
support safe-mode initialization with resolved model metadata to use overrides.

## LandingBoost fixes

Mapped LandingBoost fixes require the 0.5.3 worker (or later) with its approved GitHub checkout. The public installation above supports these tasks; older workers leave them pending.

In Velocity's LandingBoost settings, map the exact page, its approved `org/repo`, and Claude Code or Codex. Enable assignment events for that native agent. With **Manual handoff**, load delivery status and choose **Queue agent fix** for a current ready finding; automatic work can remain off. To start fixes as callbacks arrive, choose **Queue a native agent** and also enable automatic work. Saved plans that need input or review and monitoring notifications do not schedule fixes. Ordinary issue assignment remains available.

The worker verifies `origin` against the page grant before claiming a task or editing and uses an owned writable worktree. Its local Git sign-in reads the approved repository’s default branch; a generic issue mapping does not override the page grant. An explicit `--repo` can select the approved checkout, or an unambiguous saved link for that repository can be reused. `--allow-delivery` requires the workspace GitHub issue mapping to match the approved page repository before any host push/PR; a mismatch preserves local commits and reports the needed correction. Existing source-checkout changes are preserved. The platform rechecks the latest saved report at claim and stops revoked connections, mappings or permissions; manual handoff also requires the initiating person's current workspace admin access. Repeated findings reuse one run across manual clicks, callback retries and reconnects. Inspect the linked issue for actual checks, commits and proposed changes, and the LandingBoost delivery panel for run status. A failed fix can explicitly retry the same run twice; retries do not start new scans or deploy changes.

## Native usage and cost

Worker 0.5.15 records native model usage separately from Velocity
AI credits. Requires the native usage server/migration. Codex now
resolves and pins inherited native defaults before claiming work. Claude Code
captures resolved models from terminal telemetry when supported. Run details
label API-equivalent estimates, actual reported charges and unavailable data;
subscription estimates do not imply an additional invoice or marginal charge.
See [native usage and pricing coverage](https://docs.velocity.quest/integrations/codex).

## Anthropic API worker

Set your `ANTHROPIC_API_KEY` and enable Local API execution in Velocity:

```sh
VELOCITY_WORKSPACE=your-workspace velocity-agent run --executor anthropic
```

Worker 0.5.9 verifies the configured model through the same API client before claiming a run. A valid alias resolves to one model ID used for every turn and the run result; each subsequent attempt checks again. Invalid models, unavailable metadata, missing credentials and cancellation leave queued work pending. The metadata check has a ten-second deadline with no automatic retry and does not run inference or guarantee remaining credits. Use `--model MODEL_ID` to select an available model; the worker never falls back to another model. Idle polling, status and native workers do not make this API check.

This method calls the Anthropic API and uses API billing. It is not Claude Code subscription execution. Your Anthropic key stays on your machine.

## PRDs and user stories

Worker 0.5.4 adds PRD, requirement and user-story context and manual planning operations to Claude Code and Codex. The configured Velocity server must provide the planning MCP tools. Only operator-selected changes should be applied; PRD approval always remains with a human.

The API executor discovers its issue and planning schemas through authenticated `tools/list` for the current workspace and execution. It does not carry a separate copy of the server schemas or grant account administration/deletion tools. Discovery has a 10-second deadline, a 1 MB response limit and a bounded, two-minute in-memory cache scoped to the exact claim. An older server without planning tools can still provide ordinary issue tools; a missing or malformed catalogue fails the run before a model request.

The API executor can also request metered planning proposals. It presents generated proposals for human review and cannot apply them in the same execution, including by creating an ordinary issue. Apply the selected changes in a subsequent explicitly requested manual run. Cost estimates alone do not create proposals. Native workers expose manual planning tools, without enabling the platform's AI proposal tools. Planning writes remain subject to current role/scope, run policy, emergency stop and server validation; restricted automation and source-bound LandingBoost fixes cannot use them to expand their scope. Platform AI plan, credit and budget rules remain in force.

Use `--base-url https://your-velocity-instance.example` for a different server, `--once` for one batch, and `velocity-agent run --help` for all options. `velocity-agent status` reports pending local API runs; it does not prove that a native worker is online. Enable a worker only for repositories and team work you authorize it to process.

### Console verbosity

Set `velocity-agent run --verbosity QUIET|NORMAL|FULL` or
`VELOCITY_AGENT_VERBOSITY`. Values are case-insensitive; the command-line option
overrides the environment variable. Invalid values stop startup.

| Level | Console output |
| --- | --- |
| `QUIET` | Warnings and errors only. |
| `NORMAL` (default) | Work-start notices after a successful claim, progress, issue comment/status actions and concise command/tool identities and outcomes. Failures include a brief reason. Full command output, detailed logs, model text and tool arguments/results require FULL. |
| `FULL` | All available execution events, including model text, prompts, commands/output, tool inputs/results, native diagnostics and runner activity. |

```sh
velocity-agent run --agent codex --team YOUR_TEAM --verbosity FULL
VELOCITY_AGENT_VERBOSITY=QUIET velocity-agent run --executor claude-code --team YOUR_TEAM
```

The level applies to the runner, Codex, Claude Code, API execution and live
progress output, including `--once`. It controls worker activity logs; commands
such as `login`, `status` and `repo list` retain their requested output.
`FULL` is a local diagnostic view and can display sensitive issue and repository
material. Authentication headers and credential configuration are not logged;
known worker/environment credentials and structured credential fields are
redacted. This is not a general-purpose secret scanner for arbitrary file or
command output. All levels publish the same progress codes and bounded,
redacted command failure diagnostics to Velocity. Other detailed console activity
remains local.

Execution summaries are bounded to 240 characters each for the command/tool
identifier and failure reason. They may include paths or task content from a
command. Successful command output is omitted. For example:

```text
[velocity-agent] Command succeeded (exit 0): pnpm test
[velocity-agent] Command failed (exit 128): git fetch origin — fatal: unable to connect: Connection refused
[velocity-agent] Tool succeeded: velocity/get_issue_context
```


Shared execution controls require worker 0.5.7 or later. **Require isolated worktrees** keeps workers with `--single-checkout` and API-only workers idle. **Local changes only** overrides `--allow-delivery`: the host keeps and links local commits without pushing or opening a PR. Existing delivery permissions still require local `--allow-delivery`; shared settings never grant it. Controls refresh before delivery, and restrictions changing in flight preserve your local changes. Delivery eligibility can only narrow during a run; lifting local-only controls applies to a subsequent attempt after fresh repository verification. Older workers cannot claim work while these restrictions are active. Private draft preferences are not activated by upgrading.

### Delivery authorization and recovered runs (0.5.36)

Allow delivery selects what a worker may attempt. Current issue ownership,
workspace policy, integration approval requirements and the authenticated
connection still apply. When one prevents delivery, normal output identifies
the issue/run and explains the specific restriction and where to review it.
Temporary failures are checked again after 30 seconds; unchanged messages are
repeated at most every five minutes.

A closed issue, changed source/workflow or superseded execution needs a new
authorized attempt rather than replaying the old delivery. The worker records
a local stop and preserves the branch and worktree. When external delivery is
recorded on an already closed issue, follow its links on the original run page.
This reconciliation does not rewrite the original model outcome or claim that
the old worker completed delivery itself.

### Live run progress

Interrupted native runs retain a fixed reason for ownership loss, intentional
stop, runtime deadline, unavailable controls or uncertain lease renewal. NORMAL
output identifies the issue/run and recovery action. Raw transport errors are
never used as the persisted reason. A late successful renewal cannot accept an
already interrupted result. Deploy `20261030080000_native_run_recovery.sql` and
the API before using this recovery protocol.

Failed native attempts do not retry automatically. After reviewing the run and
correcting the cause, use the original connection on the machine/repository
holding its task checkout:

```bash
velocity-agent repo tasks --workspace my-workspace --repo /path/to/source
velocity-agent repo resume --workspace my-workspace --repo /path/to/source --run <failed-run-uuid>
```

This creates one idempotent successor; the failed run, usage and outcome remain
history. It reuses the exact branch, base, tracked/untracked changes and original
checkout lock. Start the original connection's worker to execute it. Current
ownership, model, workflow, repository and configuration are checked again;
the previous model's done outcome is not carried forward. A missing checkout
fails closed instead of creating an empty replacement. Live locks are never
stolen; `repo recover` only releases a confirmed dead process's lock.

Cancelled runs, accepted results, another connection, changed issue ownership,
disabled controls and already queued work cannot be retried this way. A genuine
task failure may have handed the issue to Blocked; an operator must review it
and restore its original agent ownership/In Progress status before recovery.
LandingBoost and hosted runs retain their own recovery protocols.

Upgraded workers publish safe activity to the terminal and the run detail page
through `append_agent_run_events`. Deploy the run-progress migration and API
before installing the upgraded worker. Older servers show a telemetry warning;
execution and existing lease/stop checks continue. The detail page refreshes
automatically while visible, resumes from its last event cursor after a network
failure, and can load earlier pages. It retains the latest 2,000 events per run.
A worker restart uses a new execution lease; previously recorded history remains.

Progress includes checkout preparation, SDK activity, tools, recognized validation
commands, commits, delivery and the server-recorded terminal outcome. Native Codex
provides command exit status. Claude Code reports tool boundaries; validation
results without an explicit exit status say so. The API executor reports turn and
tool boundaries. Failed commands retain the command (up to 4,000 characters),
the actual exit code when reported, and up to 8,000 characters of output. Long
output keeps its beginning and end and is marked truncated. Known credentials,
common credential syntax and terminal controls are removed before upload.
Confirmed process-launch failures, including `Text file busy`, have a separate
event and no invented exit code; missing exit status without launch evidence
remains unknown. Native runtimes own command retries: the worker does not replay
a task or command with potentially completed side effects. A later retry result
is recorded separately, preserving the earlier failure.
Worker 0.5.59 or later records a failed tool call's name and one bounded reason line (up to
500 characters) in the task event and on the run page, so a failure is not left
only in local logs. A Velocity MCP tool the executor or server refused for
missing permission is marked as such: the console and the run page say access
has not been granted, that the action did not run, and to grant the worker
access (its allowed tool policy or the Velocity MCP scope of the credential it
uses) before retrying. The agent can continue; the notice never claims the
tool action succeeded. Tool arguments and results are still omitted.
Unknown SDK events, other tool arguments/results and private reasoning are
omitted; `FULL` console output includes available execution events.
Deploy `20261016160000_agent_command_diagnostics.sql` and
`20261104120000_agent_tool_diagnostics.sql` with the API before upgrading
workers to these diagnostic formats; an older server rejects a batch carrying a
tool diagnostic and shows the live-progress warning until it is upgraded.
CI/review/deployment waits require an executor to
report them explicitly; opening a PR does not mean those steps completed.

Last worker contact is independent of activity. A quiet connected task can still
be working; contact older than 30 seconds is shown as stale. Execution completion,
worker completion and delivery are displayed separately. Delivery remains local
unless authorized by the operator and workspace controls. A dropped telemetry
response is retried with the same sequence; a partial outage keeps prior history
and buffers up to 2,000 pending events in memory. Unsent events can be lost when a
worker process exits during an outage; accepted events survive refresh/reconnect.


### Task identity and final worker status (0.5.26)

Every task-related output line includes its workspace and issue identifier, for
example `[velocity-agent] [my-workspace ENGIN-629] command started`. Multiline
errors retain the same identity on every line. Workspace heartbeats keep their
own scope; unavailable identifiers use a bounded run ID.

Before a clean or error exit the worker attempts a bounded final status report.
The Agents page distinguishes stopped workers from error exits, and late
heartbeats cannot revive that same exited session. Reporting failures preserve
the original exit outcome. A new process registers a new session.

### Configure deployment commands on the Agents page (0.5.27)

Expand **Worker details and settings**. The worker’s owner can enable website
workflow commands, select the default delivery stop, and enter named validation
checks plus deployment and acceptance commands. Use `Name :: executable arguments`
for each validation line. Save and start; the worker loads changes before the next
task, reports its applied revision and loaded capabilities, and rechecks the saved
revision before claiming. An active attempt keeps its pinned workflow.

Choose **Vercel** to use built-in deployment and HTTP acceptance. Supply the
project/team IDs, existing production URL, acceptance path and expected response
text. Vercel CLI and its local sign-in (or VERCEL_TOKEN) must be available on this
host. The worker builds from a clean checkout of the exact merged commit, waits
for Ready, guards production alias changes, promotes the selected project, and
checks the source/artifact/alias identity around the HTTP 200 and response-text
check. It refuses to replace a known deployed descendant with older source and
can reuse an already Ready exact-source artifact. Custom commands support more
involved acceptance, multiple projects and other providers. No token enters the
website settings, child command arguments or recorded receipt.

Commands execute directly in the task checkout. Use real scripts for shell pipelines
and provider adapters. The deployment and acceptance receipt contract is documented
below and in the editor. Credentials remain in the host environment or provider
sign-in; do not paste them into website commands. Only the machine owner’s signed-in
browser can change executable commands. Issue text and managed tools cannot.

An explicit `--workflow` file takes precedence; its changes require a restart.
Explicit `--allow-delivery` or `--no-allow-delivery` also override website workflows.
Protected requirements are never lowered to clear a blocker. A blocked preflight
identifies the issue and missing commands once at NORMAL verbosity, keeps unclaimed
work queued, and permits other compatible issues. Only successful preflight or an
authoritative empty eligible queue clears it. Details show the actual reported
worker version separately from the native runtime version; older workers need an
upgrade to enable website command configuration.

### Discover project workflow defaults (0.5.30)

The worker retrieves the Vercel project linked with `vercel link` in its selected
checkout. New workflow drafts automatically fill project/team IDs and a single
verified production URL. When several production domains exist, choose one in
**Use discovered settings**. Validation commands, a conventional health endpoint
and the applicable `vercel.json` path are detected from the selected application.
Review the editable draft, then save and start; discovery never enables delivery.

For Node projects, discovery reads `package.json`, the package manager and lockfiles.
It prefers `test:ci` over `test`, then typecheck and lint, with build as a fallback
when no validation scripts exist. Commands target the selected app in a monorepo.
Known watch scripts are omitted; a simple Vitest script receives `--run`. Other
project types or missing scripts need a manual validation command or an explicit
validation waiver. Script bodies are never uploaded or executed during discovery.

Next.js App/Pages and conventional Vercel health files supply `/api/health`,
`/health`, `/healthz` or `/readyz`. A literal Next.js `basePath` is included.
Only a simple constant successful response supplies expected text. Dynamic
responses use an explicit **Only require HTTP 200** check; when no health route
is found, the default checks `/`. Redirects and non-200 responses fail acceptance.
A status check still requires the exact source, project, Ready artifact and
production alias. Add a stronger text check or custom acceptance command for
application-specific requirements. Existing saved workflows and manual edits,
including deliberately emptied fields, are preserved on refresh.

Discovery uses local Vercel sign-in or `VERCEL_TOKEN`; no provider credential,
absolute checkout path, environment variable or raw API response is sent to Velocity.
It reads `.vercel/project.json`, bounded project files and only Vercel’s read APIs. It does not
deploy, link a project, run repository scripts or enable delivery. A monorepo’s
selected checkout must have the intended project link; custom/multiple-project
workflows and manual fields remain available.

Details refresh automatically about once a minute and arrive on the next
heartbeat. Missing links, sign-in and access errors appear in the form. An
explicit `--repo` wins over website repository selection; otherwise select an
unambiguous workspace/team/project repository link. Old servers keep working
without discovery, and older workers show upgrade guidance in the website.

### Private delivery configuration

Run a native worker with `--workflow /absolute/path/workflow.json`. Keep the file
private (`chmod 600`); commands come from the operator, never issue prose.
Existing local-only behavior and the legacy `--allow-delivery` PR handoff remain
available. Choose one option. Example for a repository whose tests are `pnpm test`:

```json
{
  "version": 1,
  "policy": {
    "mode": "merge",
    "validationRequired": true,
    "deploymentRequired": false,
    "maxRepairAttempts": 1
  },
  "checks": [{ "name": "Repository tests", "argv": ["pnpm", "test"] }]
}
```

Modes `local` and `pr` produce explicit handoffs without marking the issue Done.
Modes `merge` and `deploy` require workspace owner/admin access. Protected workspace
limits, current membership/grants, mapping, approval settings and emergency stop
remain authoritative. Validation is bound to the exact Git tree, including new
files. Required checks cannot be skipped. For an intentional low-impact skip,
set `validationRequired: false` and a meaningful `skipValidationReason`.
Commands execute without a shell; pass credentials through the environment,
never argument values. Outcomes, command identities and source SHAs are recorded.

A deployment requirement needs `mode: "deploy"`, `deploymentRequired: true` and
`deployment: { "deploy": ["your-release-script"], "verify": ["your-acceptance-script"] }`.
Both adapters receive `VELOCITY_DELIVERY_SOURCE_SHA` containing the confirmed
merge SHA. Deploy prints a single JSON receipt `{ "sourceSha": "...", "artifactId":
"...", "url": "https://..." }`; diagnostics go to stderr. Verify receives the
receipt on stdin, verifies the actual released artifact and meaningful acceptance
checks, and prints the same identity with `"acceptancePassed": true`. No adapter,
failed acceptance, or a source mismatch means no Done. Merge-only never claims
a production deployment. Operator scripts must be idempotent for the source SHA.

CI waits persist in Velocity and in private Git metadata, release the native
turn, and resume on a later poll/restart with the same authorized account,
repository mapping and configuration. An active checkout lock cannot be stolen;
after confirming a crashed worker is stopped, use `velocity-agent repo recover`.
Jobs preserve their original stop point and commands, so editing a configuration
cannot silently upgrade an existing job. Relevant validation/CI failures may
queue 0–3 bounded native repair attempts (default 0), retaining the original
runtime deadline. Exhaustion records Blocked and preserves work. Provider outages
wait for a later poll without another coding turn. GitHub checks/reviews are
re-read on the exact PR SHA at the merge boundary, without protection bypass.

The run detail page distinguishes coding completion from validation, PR, CI,
merge, deployment and issue closure. The final evidence comment and Done transition
commit together and survive a lost response without duplication. Saved delivery profiles and per-issue choices refine the same operator workflow as described below.

When another run or person takes over, open **Delivery continuations** on the
original run and link the specific successor run, PR or follow-up contact. The
successor links back to its originating runs. Coding completion and an issue
marked Done never establish deployment acceptance. A removed source or repository
grant hides its old references; the original run's execution outcome is retained.

A failed Vercel build or acceptance check records a blocked handoff rather than
starting another deployment on each poll. Temporary provider API failures keep
the existing delivery stage pending without another coding turn.

For a deployment completed outside that run, an owner/admin can record a host
acceptance receipt for its merged PR. With the Vercel preset, rerun the same
`velocity-agent workflow vercel-verify` command with `--external-receipt`, passing
the deployment receipt on stdin and redirecting stdout to a private JSON file.
This performs the real Ready, exact-source, production alias and HTTP acceptance
checks. Artifact links identify the immutable deployment; HTTP acceptance checks
the configured production origin. Then run:

```bash
velocity-agent workflow record-delivery --workspace my-workspace \
  --run ORIGINAL_RUN_UUID --pr https://github.com/org/repo/pull/123 \
  --receipt /private/path/accepted-deployment.json
```

The host uses its existing Velocity authentication. The server confirms the
current repository mapping, exact merged commit, head checks and required reviews,
and records a PR origin reference before accepting the receipt. A missing check,
rejected acceptance or revoked authorization keeps delivery unverified. Recording
external acceptance does not change the original execution result or close the
issue. Review and close the issue separately after its acceptance criteria pass.

### Public package releases are delivery targets (worker 0.5.43)

A merged PR or a verified Web deployment does not complete a change to this
worker (or the management CLI) while the public immutable archive still carries
older source. The host selects affected packages from the delivered diff's
actual build inputs: `packages/agent/src`, `packages/cli-core/src`, their
`package.json`/`tsconfig` files, the release packer, and `pnpm-lock.yaml` only
when a shipped importer's resolutions changed. Documentation, tests and
unrelated application changes never require a publication.

Some compiled sources are generated from files outside the package. The
management CLI's command and coverage inventory changes when an API route,
product page, GraphQL schema module or MCP tool is added or removed, even when
that route (for example a privileged cron job) never becomes a command. Worker
0.5.60 or later checks those generated sources before choosing targets (product
repository only):

- When the change reaches a generator input, host validation also runs the
  read-only `pnpm --dir packages/cli run check:coverage`. It regenerates offline,
  compares bytes with the committed files and lists each stale file, so a stale
  inventory takes the ordinary bounded validation repair.
- Before any PR, the same check runs unless it already passed in validation for
  the exact delivered tree. Stale output, or a generator that cannot run, blocks
  with `BINARY_GENERATED_SOURCES_STALE`; nothing is pushed. Run
  `pnpm --filter @velocity/cli generate` on the preserved branch and retry.
- Targets are then chosen from committed paths as above. A regenerated file
  under `packages/cli/src` selects the management CLI; an implementation-only
  edit to an existing route regenerates identical bytes and selects nothing.

When a package is affected, delivery records it and:

- Refuses to open a PR while the package version at the delivered head is
  already staged or published (`BINARY_VERSION_PUBLISHED`). An immutable
  release can never be rebuilt; advance the version in a new attempt.
- After merge and any required deployment, waits at the `release` stage. One
  handoff comment names the exact relay command
  (`node packages/agent/scripts/release-from-ci.mjs RUN_ID ENGIN-ISSUE` from
  the merged commit or a later main commit that includes it). The issue stays
  open; a version label, merged PR, model result or Web artifact is not enough.
- Rechecks the public release without a coding turn: the published archive's
  SHA-256, `release/source.json`, the trusted product CI run and the public
  Node 18/22 install matrix must agree, and the release source must be the
  merged commit or a descendant of it. A published version built from older
  source, or with failed install checks, blocks with `BINARY_RELEASE_MISMATCH`
  and needs a new version.
- Completes the issue only after the server re-verifies that evidence through
  the workspace GitHub connection and records it in the completion comment.

A release that was published later or in a batch can be linked to the original
run with a host-verified receipt. From the product checkout on the worker host:

```bash
velocity-agent workflow verify-release --target velocity-agent --release-version 0.5.43 \
  --includes MERGED_COMMIT_SHA > /private/path/release-receipt.json
velocity-agent workflow record-release --workspace my-workspace \
  --run ORIGINAL_RUN_UUID --receipt /private/path/release-receipt.json
```

The server checks the receipt against the public release, the product CI run
and the original run's recorded merge commit before accepting it. Original run
outcomes, handoffs and current authorization are retained; the issue is
completed separately by a person after review. Set
`VELOCITY_RELEASE_READ_TOKEN` to a read-only GitHub token only to raise
anonymous API rate limits; it is never sent to release downloads.

Stop an unfinished workflow from its run detail page (runner owner or workspace
administrator), even after the coding turn has completed. This records Blocked
and preserves code. A single checkout stays reserved for its pending delivery;
only its queued repair may resume until the workflow hands off or finishes.

### Per-issue model choices (worker 0.5.16)

Open **Agent model overrides** on an issue to save model/effort choices separately
for `codex`, `claudeCode` and the local `anthropic` API worker. Empty fields inherit;
clear all overrides to restore defaults. Claude Code effort requires a model;
Anthropic API accepts a model only. Hosted execution keeps its platform policy.

Explicit `--model` and `--effort` flags override their corresponding issue fields.
Issue fields override inherited worker/provider defaults. Shared workspace scope,
concurrency, runtime, stop and delivery limits remain authoritative. This feature
does not select another billing method, provider, repository or permission grant.

The worker reads server-authoritative settings before Git fetches/claims and
validates them using its exact native runtime or API metadata client. Invalid or
unavailable settings leave work pending. Current settings apply to queued/new
attempts; running attempts and approval resumes retain their validated selection.
Older workers cannot claim applicable issue overrides. A pre-upgrade suspended API
conversation without a saved choice requires recovery using its original worker.

Issue editors with member access can read/set/clear settings through GraphQL,
REST, MCP `create_issue`/`update_issue`, and management CLI 0.2.25. Managed workers
cannot edit these execution settings. See the public Codex/Claude integration
guides for API fields and CLI examples; model IDs and effort are configuration,
never credentials.

### Per-issue workflow choices (worker 0.5.22)

Open **Agent workflow** on an issue before assigning an agent. Choose local
implementation, PR handoff, merge after CI, or deployment with verification;
require validation and name existing host checks. Save applies settings only to
that issue. **Clear workflow overrides**, then Save, restores inheritance and
clears recorded cues. Merge and deployment require an owner or admin.

The worker inherits its profile/user delivery preference when no issue choice
exists. An explicit `--workflow` wins by default. To let authorized issue choices
replace its defaults, add `"issueOverrides": true` alongside `"version": 1` in
the private workflow file. Website workflows provide the same opt-in in the editor.
An issue cannot remove required host checks, supply commands, bypass workspace
approval or repository protections, or authorize merge for a member. An explicit
CLI delivery flag also takes precedence. The preview uses recent connected-worker
reports; the worker resolves actual settings again before claiming.

For a direct user cue, write one of these lines in an issue description paragraph
or a new comment in Velocity:

```text
/agent-workflow implement and test only
/agent-workflow open a PR but do not merge
/agent-workflow complete delivery and mark Done after verification
```

Use only one directive. `local`, `pr`, `merge`, `deploy` and `inherit` are also
supported. Quoted text, code, attachments, imports, API text and agent comments
cannot grant rights. Structured overrides take precedence over cues. Conflicting
or unsupported directives need a structured selection before work proceeds.
The issue shows the recorded interpretation and source, effective worker values,
and the last pinned attempt/revision.

Queued changes apply on the next attempt. A workflow edit during active work
stops delivery at the next authorization boundary and requires a new attempt;
it never silently widens an existing attempt. Once delivery is prepared, reassign
the agent to start a new run; an ordinary retry preserves the original delivery
evidence. Recover saved changes with `velocity-agent repo tasks`. Changes and immutable attempt
receipts are audited. Local edits remain available for recovery. A worker without
configured checks/adapters reports unsupported settings and leaves work queued.


### Saved delivery profiles (worker 0.5.24)

In **Settings → Agents → Delivery profiles**, owners/admins save shared defaults
and protected limits; members save their own preferences within those limits.
Personal preferences belong to the connected worker’s signed-in account in this workspace.
Stable IDs are `codex`, `claudeCode` and `anthropic`. Codex/Claude Code support
native delivery. Claude API has no native Git/CI/deployment adapter support; that profile is read-only.
Capabilities are defined by the installed release, not a second platform defaults
system. Model/effort settings remain independent.

Profiles support `local`, `pr`, `merge` and `deploy` stops, validation and deployment
verification requirements, and named host checks. Local/PR stops preserve an open
issue for handoff. Merge/deploy require current owner/admin authority. CI/review
and closure dependencies cannot be disabled separately. Deployment requires both
operator-owned deploy and acceptance adapters.

Add `"profilePreferences": true` once to the private `--workflow` file to inherit
saved defaults/personal preferences without repeating `--allow-delivery`. Keep
credentials on the host; commands may also be configured in the owner-only website editor. Existing files keep their
explicit stop; existing local-only installations are never automatically upgraded
to delivery. `--no-allow-delivery` stays authoritative. A workflow and an explicit
delivery flag are mutually exclusive. To allow only per-issue choices while
retaining host defaults, the existing `issueOverrides` opt-in remains supported.

Protected system/workspace/provider policy and profile limits apply first. Within
those boundaries, precedence is explicit CLI > issue/cue > personal > shared >
host fallback. Host-required checks and deployment verification cannot be waived.
A nonempty check list requires validation. An empty personal check list clears inherited check preferences; protected check names remain required.
A profile grants no repository, credential, GitHub or deployment access.

The connected worker reports the next-attempt profile, shared/personal revisions,
sources and missing checks/adapters. Claim pins the profile with the issue choice;
write and delivery boundaries revalidate it. Any saved edit requires a fresh
attempt, even if it only relaxes a limit: in-flight delivery cannot gain rights.
Retry preserves prepared evidence; reassign for a new run and recover saved work
with `velocity-agent repo tasks`. Older workers cannot ignore newly configured
shared profiles: upgrade them. Run details show frozen settings separately from
actual delivery progress. Settings retain an audit history of shared and your own
changes.

Use MCP `get_agent_delivery_profile` / `update_agent_delivery_profile` or GraphQL
`agentDeliveryProfile` / `updateAgentDeliveryProfile`. Updates require both the
edited scope's `expectedRevision` and `expectedSharedRevision`; reload conflicts.
Personal settings are the workflow fields above; shared settings contain
`defaults` plus `limits` (`maxMode`, `validationRequired`, `deploymentRequired`,
`requiredChecks`). Clear personal settings with `{}` to inherit again. Caller
identity owns personal preferences; no user selector is accepted. Managed runs
cannot change these controls. The management CLI exposes `agents delivery-profile`
and `agents update-delivery-profile` in the selected authorized workspace.


## Live provider sessions and steering

New session-control servers let native Codex workers use Codex App Server. The worker records the provider thread and active turn, streams progress, and accepts separately authenticated operator steering. Existing servers and older workers retain their one-shot executor; they do not advertise live steering.

For code-capable Claude Agent SDK execution, configure a local `ANTHROPIC_API_KEY` (or `--anthropic-key`) and select the native `claude-code` executor. The packaged SDK provides its code harness; it uses a private session directory and does not inherit Claude subscription or OAuth sign-in. Without an API key, the existing local Claude CLI executor remains available and does not offer these session controls. The `anthropic` executor remains the separate metadata-only Messages tool loop.

An owner or admin can read `velocity-agent session status --run <run-id>` and then use `steer`, `interrupt`, or `resume` for that run. Commands include the expected execution, generation, provider session and turn. Refresh status after a turn changes. An old command cannot interrupt a newer turn, and an operator removed before command delivery loses authority over queued commands too.

Codex steering targets the active turn. Claude SDK steering is queued for the next turn boundary. Model and effort changes require an interrupted session and a supported resume boundary; provider changes require a new run. Explicit CLI model and effort settings take precedence over web/operator overrides. Protected workspace model constraints still apply. Unsupported operations are rejected and reported in session status rather than silently choosing another model or executor.

Interrupting preserves the owned task worktree and provider session. The worker stays connected and maintains its lease while waiting for an explicit resume, subject to its run timeout and current authorization. Lease loss, membership/grant revocation, stop controls and shutdown stop execution and retain local state; they do not authorize automatic re-execution. A recovered active session requires an explicit resume. Checkpoints are private under the local Velocity agent data directory; `VELOCITY_SESSION_STATE_ROOT` can place them in a persistent, tenant-isolated hosted directory. Preserve the corresponding provider session files as well.

Issue/comment journal events invalidate queue selection at the next task boundary. Priority, due date and age are handled deterministically; comment text cannot grant steering authority, expand scope or become a system instruction.

Provider contracts: [Codex App Server](https://learn.chatgpt.com/docs/app-server), [Claude Agent SDK overview and API authentication](https://code.claude.com/docs/en/agent-sdk/overview), [streaming input](https://code.claude.com/docs/en/agent-sdk/streaming-vs-single-mode), and [session resume](https://code.claude.com/docs/en/agent-sdk/sessions). Runtime-specific wire fields are checked against the pinned Codex runtime's generated schema.

### Issue monitoring (0.5.32)

Workers can call `monitor_issue` for issue-scoped committed edits, linked integration callbacks and agent status changes. Resume with its cursor and reread issue context before acting. `wait_for_issue_checks` waits up to 20 seconds for the exact linked PR, repository, branches and head; repeat the same call after timeout. Completion can mean failed checks. Neither tool starts a background model turn or grants merge/deployment authority; emergency stops and execution leases still apply.

### User configuration for a hosted run

In **Agents**, open an eligible pending Claude Code issue run, then
**Hosted execution → Run in the cloud**. A workspace owner or admin enters the
repository test command, selects a machine-size preference and time limit, and
chooses **Preview machine size**. Review the resolved resources before
**Queue hosted run**. Cloud work needs an enabled backend, the mapped repository
and workspace policy that permits it. Codex and the other native runtimes use
their local-worker paths; this control runs Claude Code with server-side API
authentication, not a Claude subscription sign-in.

Select an optional **Agent configuration** JSON file before previewing. The
file is an explicit selection for this run; Velocity does not copy the machine
operator's home or another user's saved settings. For example:

```json
{
  "version": 1,
  "files": [
    { "path": ".claude/CLAUDE.md", "content": "Use concise explanations." },
    { "path": ".claude/settings.json", "content": "{\"language\":\"French\",\"alwaysThinkingEnabled\":true}" },
    { "path": ".claude/skills/review/SKILL.md", "content": "---\nname: review\ndescription: Review changes\n---\nCheck tenant isolation." }
  ]
}
```

Bundles are limited to 6 KB of JSON and 20 files. Supported paths are
`.claude/CLAUDE.md`, `.claude/settings.json`, and Markdown files under
`.claude/skills/<skill>/`. User settings accept `language`, `outputStyle`, and
`alwaysThinkingEnabled`. Authentication, environment, permissions, hooks and
MCP settings stay controlled by the hosted workflow; credential files are
rejected. The same bundle can be sent as `agentConfiguration` with the
browser-authenticated `/api/agent/hosted` `enqueue` action.

The server requires `INTEGRATION_ENCRYPTION_KEY`, encrypts the entire selection
at rest, and binds it to the submitting user, workspace and run. The guest
fetches it using the active run capability, installs private files in a fresh
attempt home under `/run`, and loads only those user settings. Transfer or
setup failure stops execution and reaches the existing hosted result workflow.
Raw process logs are disabled for configured runs; diagnostic redactions and
checkpoint scanning also protect selected file contents. Configuration and
provider session state for these runs stay ephemeral; repository work and
sanitized hosted result evidence remain checkpointed. A resumed task must
install its configuration again with a newly authorized attempt. Existing runs
without a selection keep their current behavior.

Delivery waits identify the exact PR commit and distinguish running checks, required reviews, requested changes, conflicts, repository policy, drafts and externally changed commits. The Agents page shows pending delivery even when coding workers are idle. Actionable waits send one owner handoff per reason and commit; recovery on the same PR clears the wait automatically.

Native repairs use the existing `maxRepairAttempts` policy (0 by default, at most 3). With no remaining budget the worker preserves the checkout and asks the owner to act. Opted-in conflict repairs prepare the current confirmed base in the owned task worktree; dirty or changed checkouts and revoked access stop before merging. Earlier coding outcomes stay recorded in repair history. An external PR head requires an authorized continuation instead of silently adopting another commit.


### Local validation during a GitHub Actions account outage

Worker 0.5.51 keeps account-capacity failures (jobs rejected before any steps)
and unavailable check diagnostics in a delivery wait. It does not spend coding
repair attempts or rerun GitHub jobs for these conditions.

An owner or admin can authorize passing local checks under **Settings → Agents
→ Delivery defaults & overrides → Local checks during a CI account outage**.
Choose the repository, durable worker, required validation check names, reason
and expiry. The run records the exact commit/tree, commands, results and an
immutable receipt. The server identifies the worker that actually collected
validation from its current signed-in session and private worker identity key; a coding worker ID alone is not
validation provenance. Changed source needs new checks. Revoking or expiring the
approval stops further protected delivery actions until renewed or ordinary
GitHub checks pass. Real failed jobs, reviews, branch rules and public package
release verification still apply. Previously blocked runs require explicit
recovery from their original connection and checkout; a grant does not reopen
them automatically.

#### Local-only validation while the Actions budget is paused

The same setting offers **Local-only: skip GitHub Actions**, which an owner or
admin must select explicitly; existing grants and the default stay
fallback-only. The form previews the repository, worker, required checks and
expiry before approval. With worker 0.5.60 or later and a current local-only
grant that this run's own receipts satisfy, the delivery commit is titled
`ISSUE-1: Complete delivery run <run> [skip ci]` with a note naming the
approval, and the host's squash merge uses GitHub's generated title plus
`[skip ci]`. GitHub then creates no push or pull request workflow runs, so no
jobs are queued or billed. With no Actions run reported for the exact head,
the recorded receipts for that tree are the accepted CI source and are labelled
as local, never as GitHub success. Any other reported check must still pass;
if Actions run anyway, their own result applies.

Ordinary workflows, other workers and other repositories keep their configured
CI. An expired, revoked or superseded grant, changed approver authority, a
different validation worker or changed source stops protected delivery; a
skip-marked head then waits for CI rather than being accepted. If the grant
changes before an unpushed head is pushed, the host only rewords that commit
(same tree, no new or empty commit). Public binary releases are still built by
trusted CI on the merged commit or recorded by an explicit owner release
waiver, so those deliveries wait at the release stage.
Deliveries validated by a worker older than 0.5.51 have passing receipts but no
record of which worker ran them, so an approval cannot accept them. When such a
delivery waits at checks or merge on an account outage, a 0.5.60 or later worker
named by a current approval for the repository reruns the configured checks
once on the exact PR commit and tree. It runs no coding turn, uses no repair
allowance, reruns no GitHub job and creates no commit. The server reserves the
pass before any command runs, under the delivery lease and the worker's current
session, and records that worker as the validator. The earlier receipts, the
coding result and repair history are kept. Passing receipts then follow the
normal local-check path, including reviews, branch rules and current approval
rechecks before merge. A failed pass is recorded beside the earlier receipts and
the delivery keeps waiting. Each approval allows one pass per commit and
configuration. A restart or lost response reconciles that same pass instead of
starting another one. After a failure or interrupted pass, an owner or admin can
renew the approval to allow one more. The run page and terminal output say
whether the problem is older receipts or a missing, expired or mismatched
approval, and give the next safe action.

### Automatic repairs and failed host checks

Worker 0.5.53 reports a bounded, redacted explanation of failed host checks in normal output and the run's Delivery workflow. Recognized assertion, test, type, lint, startup and timeout reasons are evidence, never instructions or authority. Command digests and exit status remain authoritative. Fuller redacted logs stay private in `<git common dir>/velocity-agent-diagnostics/<id>.log` with owner-only permissions; new writes remove logs older than 14 days and retain the newest 50 per repository. Capture or disk failures never make a failing check pass.

In a worker's workflow settings, an owner/admin can set **Automatic repairs per run** to 0–3, or inherit the enabled shared profile's default. Omitted defaults remain zero; upgrading does not enable paid repairs. Explicit CLI values (including zero) take precedence over saved defaults, and a protected shared maximum can narrow the allowance. Repairs use the original runtime and token budgets.

For an already stopped delivery, open its run and choose **Review repair continuation**. An active browser owner/admin can approve a bounded additional allowance for one hour, with a recorded reason. The original policy stays pinned. This requires the original compatible connected worker, unchanged source/assignment/configuration, current delivery permission and remaining runtime. Changed sessions or expired budgets require review and a new authorized attempt. Approvals can be revoked; expiry, revocation and approver demotion prevent further native claims and renewals. The worker reruns the delivery check before spending a repair. Billing and provider outages wait without consuming coding repairs.

A missing executable remains at validation with its startup diagnostic saved. Fix the executable or environment on the original host; the next poll retries validation without another coding turn. Passing checks clear the earlier startup error.
## Cloud machine backends

Platform administrators manage cloud machine integrations in **Admin → Cloud
backends**. Daytona supports new jobs through the configured backend.
Instabox remains available for historical recovery until its separate
retirement checks are complete. The dispatcher
leases jobs through the backend registry; the worker runs creation, execution,
checkpointing and cleanup through `HostedMachineProvider`.

Apply the backend migrations and deploy the control plane before upgrading a
`hosted-worker` at a task boundary. The current verified dispatcher and guest
release is [0.5.74](https://github.com/velocity-quest/velocity-agent/releases/tag/agent-v0.5.74).
Older unsupported dispatchers receive an upgrade response before leasing work.
An administrator must save the provider configuration and key before enabling
new admissions. Configure the server's existing
`HOSTED_BACKEND_ENCRYPTION_KEY` on both the Web and Admin deployments before entering credentials; backend credential
writes fail closed without encryption. API keys are write-only in admin; blank
replacement fields keep the saved key. Configuration edits use revisions, so a
stale editor must reload before saving.

The worker host needs `VELOCITY_HOSTED_DISPATCH_SECRET` and the existing trusted
worker distribution flags (`--worker-sha256`, `--worker-version`, and optionally
`--worker-archive` or `--worker-url`). Provider API keys, snapshot identity,
region and capacity come from the encrypted admin configuration. Legacy
`INSTABOX_API_KEY`, `INSTABOX_API_URL` and `--template-version` do not select
the new backend. An old worker/control plane cannot bypass backend admission
and must be upgraded.

### Configure Daytona and preview a job

Use a Daytona organization API key and an approved private snapshot in its
configured region. Saving verifies the snapshot's ownership, immutable identity
and resource tuple. The API key is write-only; leaving its replacement field
blank keeps the saved key. Platform admins configure simultaneous-machine and
aggregate CPU/RAM/disk ceilings. A zero machine limit pauses new admissions.
An Admin save does not start a sandbox.

Under **Approved Daytona machine sizes**, a platform admin may enable separate
immutable snapshots for Small, Medium and Large, and choose the Auto fallback.
The standard sizes are 1 vCPU / 1 GiB RAM / 3 GiB disk, 2 / 4 / 8, and 4 / 8 / 10,
respectively. The run preview is authoritative about which sizes are approved
and available for this deployment. Image size, allocated resources and actual
CPU/RAM utilization are different measurements.

The job's explicit choice takes precedence over project and workspace size
preferences, including an explicit Auto choice. Declared minimum resources from
those scopes still apply. Auto can reuse an exact matching successful workflow
allocation. Without matching history, it selects the smallest approved size
satisfying declared minima; when neither requirements nor history exist, it
uses the platform fallback. It does not infer
peak memory from issue text or elapsed time. Live CPU and memory utilization
are not currently measured.

**Preview machine size** shows the selection reason. Enqueuing freezes the
snapshot, resources and relevant policy revisions. A changed preview must be
refreshed. Recovery keeps the original size and deadline; a larger machine
requires a new authorized job. Review **Project and workspace defaults** in the
preview to change preferences for future jobs.

Workspace Emergency stop, Local execution preference, local-only delivery,
unfinished issue prerequisites, missing backend credentials, provider readiness
and capacity can keep work pending without a model call. Open the run's
readiness explanation: workspace owners/admins handle workspace policy;
platform admins handle backend, dispatcher and provider access. Finish linked
prerequisites or correct their relations rather than repeatedly requeuing.

Cloud execution currently prepares a validated PR handoff. Review the run's
coding, delivery and compute-cleanup states separately. **Compute released**
confirms infrastructure cleanup; follow the delivery links to determine whether
the required review, merge and deployment have finished. Checkpoints preserve
repository work across a dispatcher loss, but recovery does not replay coding
or automatically resume an interrupted task.

See the [cloud execution guide](https://docs.velocity.quest/integrations/claude#cloud-execution)
for the workspace flow and the run's next action. Keep original provider and
encryption keys available while historical allocations still need recovery.

### Dispatcher distribution and recovery

Bundled workers use the pinned HTTPS release archive (up to 32 MiB). The
dispatcher and guest both enforce this download bound and the pinned checksum.
Dispatcher package inspection also bounds expanded tar contents to 256 MiB.
The optional `--worker-archive` sends its contents inline through the provider
API and retains a smaller 512 KB limit; use the default release URL for bundled
SDK releases. Dispatcher and guest should be upgraded together.

Disabling a backend pauses new leases, leaving queued work pending. Existing
runs finish and orphan recovery continues using the encrypted configuration
snapshot saved when each run was leased. Machine credentials travel only to the
private dispatcher, outside guest task manifests, public job inventories and
admin responses. Before upgrading an existing installation, stop old dispatchers
and configure the original provider account/template so older orphan machines
can still be recovered. Legacy orphans wait for a configured credential rather
than storing an empty snapshot.

Worker 0.5.69 and its matching control plane also reconcile a lost Daytona
creation response through a separate five-minute cleanup lease. They search the
original attempt and verify its ownership, resources, snapshot and original
expiry; they never create a second sandbox or resume coding. The dispatcher
records the verified machine identity before deleting it. Empty, conflicting or
unverifiable lookups keep capacity reserved and expose the next step on the run
page and **Admin → Cloud backends**. Administrators can retry a lookup or record
an explicit provider absence check for the exact job/attempt. That decision
releases the reservation without claiming provider deletion or changing the
original execution outcome. Keep the original account and encryption keys
available until all retained allocations are resolved.

Worker 0.5.70 and later read Daytona account identity and regional/container quotas with
the organization API key; they do not require a dashboard JWT. A private snapshot
must belong to that key's organization and configured region. Missing or malformed
quota evidence keeps work waiting. Explicit inherited limits remain bounded by
regional quota; the provider still enforces inherited limits, account suspension
and concurrent usage at creation. Reusing the exact owned attempt does not count
its existing allocation twice. This change does not enable a backend or complete
the separate private-image and live cutover acceptance.

Worker 0.5.71 creates from the pinned snapshot without conflicting resource
overrides. It captures the verified snapshot name alongside its immutable ID
because sandbox reads return that name. Cleanup accepts the provider's exact
owned deletion tombstone only while destroying/destroyed, then waits for terminal
destruction or 404; the rename alone never releases capacity or permits execution.

When rotating a provider key, keep the old key valid until machines using it
have been cleaned up. Similarly, retain the prior `HOSTED_BACKEND_ENCRYPTION_KEY_PREVIOUS`
while any retained backend snapshot requires it. Do not remove a provider
implementation while it still has machines needing recovery.

Adding a backend requires an engineering change: register its validated public
configuration and encrypted credentials on the server, implement and register
its `HostedMachineProvider` factory, and migrate the configured backend and job
routing. Lifecycle orchestration does not depend on Instabox operations.

### Configurable issue lifecycle

Workspace owners/admins can manage lifecycle settings through
`agentIssueWorkflowSettings` / `updateAgentIssueWorkflowSettings` in GraphQL
(or the corresponding `velocity agents` CLI commands). These are the settings
API for the companion workspace Agents pane. Settings have a revision for
concurrent edit protection, sparse `defaults`, and sparse `providerOverrides`
for `claude`, `codex`, `grok`, `muse`, `cursor` and `antigravity`. Omitting a field inherits its workspace value; removing
an override restores inheritance. No credentials or commands belong in these settings.

The poll response includes `issueWorkflow` (version, workspace, provider,
revision, saved values and `effective` configuration). Polls are uncached.
The server also reads current settings at claim, tool writes and completion,
so existing workers and active runs follow changes without restarting.

- `start`: independently configure `assign`, `changeStatus` and `statusId`.
- `progress.comment`: allow useful intermediate context comments.
- `done`: configure `changeStatus`, `statusId` and `comment`.
- `requirements`: require host-confirmed `pushed`, `merged`, `deployed`, and
  `confirmed` evidence (all enabled by default). This cannot relax protected
  host checks or grant merge/deploy permission. Non-delivery work stays open
  unless an admin explicitly disables its inapplicable completion requirements.
- `needs_input`, `blocked`, `clarification`, `error`, `interrupted`, `no_changes`,
  `in_progress`, `cancelled`: independently configure `changeStatus`, `statusId`,
  `returnAssignment` and `comment`. Feedback, failures and interruptions return
  assignment to the initiating/assigning user recorded at claim by default.
  No-change work returns assignment and retains its status by default.

A null status uses the team's named default (In Progress, Done, Cancelled,
Needs Feedback/Blocked). An explicit status must be available on the issue's
team and have a compatible group. Missing statuses produce a failure instead
of choosing an unrelated status. Failed/interrupted runs still record their
failure with `agent_workflow_error` if a handoff cannot be applied. Human
ownership/status edits after claim remain protected. Automatic triage and
reviews do not own the lifecycle, and cancellation still requires the original
user's confirmation comment.


### Worker fleet maintenance

`velocity-agent` 0.5.55 coalesces overlapping heartbeat reads and honors a
worker-session `Retry-After` response across its heartbeat, queue-boundary and
status reports. A normal log shows the next UTC retry time. Jitter spreads
workers after that deadline; repeated responses without a usable hint use
bounded exponential backoff. A server hint is bounded to five minutes. Shutdown
never waits for that cooldown, and active execution renewal is independent of
these session reports. Every new claim still requires a fresh authorized worker
snapshot; a cached heartbeat never grants work.

The session endpoint has a separate authenticated maintenance allowance of
1,200 requests/minute per workspace/connection, with 300/minute per machine and
process session. This supports the measured session-report traffic of 20–40
idle configured workers using the default ten-second poll and fifteen-second
heartbeat, including fresh admission reads. Invalid/rotating session IDs cannot
escape the shared ceiling. Authentication, consent, worker identity, version
admission and general API/MCP limits remain unchanged.

Connected workers normally read website Start/Pause/Stop changes at the next
poll or heartbeat. During a rate cooldown, the displayed retry deadline applies;
with the default timers the next session read is scheduled by the fifteen-second
heartbeat or queue poll after that deadline, subject to bounded discovery/network
timeouts. Pause/Stop do not authorize another claim, and local Ctrl-C stops
immediately. An old server without `Retry-After` receives the same bounded
backoff. General MCP queue traffic and active-run tool/renewal traffic have their
own existing limits; this session allowance does not increase those limits or
promise forty simultaneous native executions.

### Bounded native continuation and process ownership

Workspace owners/admins can enable **Bounded native continuation** under Settings → Agents → Shared controls. It is off by default and requires worker 0.5.58 or later. Only native Codex and Claude Code issue runs participate. Each useful interrupted turn saves a source fingerprint and complete reported usage before a successor can reuse its existing worktree. The original run keeps its interrupted outcome and links to the next run. Total elapsed time retains the original hard deadline, even if workspace limits are relaxed later. Stop, lost permission, provider limits, missing usage and unchanged source do not silently start another turn. The reported-token ceiling controls scheduling; delayed usage from an in-flight provider request can exceed it, so it is not a billing cap.

On Linux, Codex launches also retain private process-birth ownership records under `XDG_DATA_HOME/velocity-agent/native-processes`. Successful runs, Stop, timeouts and worker loss clean only verified owned descendants. Restart recovery additionally requires an unchanged registered checkout and server-confirmed expired or terminal execution. `velocity-agent repo tasks` exposes retained cleanup state. Closed ownership records are bounded; source worktrees, delivery journals and provider checkpoints are retained separately. Unrecognized or unverifiable legacy processes are left for operator inspection. macOS and Windows keep the existing provider cleanup behavior; automatic birth-based orphan reconciliation is Linux-only.
