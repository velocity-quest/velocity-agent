---
name: velocity-loop
description: Drain the eligible Velocity agent queue, or keep watching a Velocity workspace for assigned agent work, by running the installed velocity-agent loop engine. Use when asked to work through, drain, process or watch the Velocity agent queue, or to run a Velocity loop. Not for editing or answering a single issue.
---

# Velocity loop

Run Velocity's own loop engine. It selects, claims and delivers work exactly like `velocity-agent run`, so do not select issues, claim runs or call Velocity issue tools yourself.

1. Confirm the engine exists: `velocity-agent loop --help`. If the command is missing, tell the user to install velocity-agent 0.5.60 or later and stop.
2. Choose the mode:
   - Default: `velocity-agent loop --once`. It drains eligible queued work and exits when no actionable work remains.
   - Only when the user asks for continuous watching: `velocity-agent loop --watch`. It runs until stopped (Ctrl+C), so start it where it can keep running and tell the user how to stop it.
3. Pass through only the choices the user made, using the CLI's options (see `--help`): `--workspace <slug>` for one workspace, and `--team`, `--repo`, `--executor`, `--agent`, `--model`, `--effort` or `--workflow` when requested. Without them the website configuration and saved repository links apply.
4. Never put tokens or keys on the command line, in files or in this conversation. The loop uses the existing `velocity-agent login` sign-in. If it reports that sign-in, a repository link, a provider sign-in or Start on the Agents page is missing, report that exact diagnostic and the setup step it names; do not work around it.
5. Act within the authorization the user already gave: do not ask again before running the loop, and do not change Settings, Start/Pause, delivery permission or repository access.

## Rules

- Do not build another selection loop, claim unassigned Todo issues, or retry failed runs. Failed runs need an explicit `velocity-agent repo resume` decision from the user.
- Issues in review, blocked, waiting for feedback, completed or cancelled are skipped by the engine. Report the reason it prints; do not move those issues.
- Successful model output never means an issue is Done. Issues close only through their recorded outcome and the configured validation and delivery evidence.

## Report

Report the final `Loop <uuid> ...` line: completed, waiting, paused, stopped or failed, with the number of claimed and failed runs and any diagnostic. A completed drain can still include issues awaiting review, CI, deployment or human input.

If the loop is interrupted, give the user the loop UUID and progress file it printed. Continue it on the same host with `velocity-agent loop --once --resume <uuid>` (or `--watch`). Resuming continues the record and selects current work again; it never replays a provider turn or takes over another worker's lease. Inspect a recorded run with `velocity-agent session status --run <run-uuid>`.
