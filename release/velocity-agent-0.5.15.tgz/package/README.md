# Velocity agent

Local workers for pending Velocity agent runs. This is separate from the general Velocity management CLI.

Requires Node 18.20 or newer. Install the compiled package from Velocity's public GitHub release:

```sh
npm install --global https://github.com/velocity-quest/velocity-agent/releases/download/agent-v0.5.15/velocity-agent-0.5.15.tgz
velocity-agent --version
```

The package is distributed through GitHub releases, not the npm registry. Product CI builds and checks the package, then distribution CI publishes it with a SHA-256 checksum on an `agent-vVERSION` tag. The product repository and its workspace package remain private; the public distribution contains only the compiled package and release materials.

Maintainers relay a successful main **Agent CLI** workflow artifact with `node packages/agent/scripts/release-from-ci.mjs RUN_ID ENGIN-ISSUE_NUMBER` from the exact checked commit, using their existing GitHub sign-in. The relay stages that checksummed archive on a new immutable `release/agent-vVERSION` branch in the public distribution repository. It never uploads a locally built package, overwrites a candidate or publishes a release; distribution CI verifies the artifact and its branch/version identity, checks clean installs and publishes it. This avoids dispatch payload size limits and needs no registry credential or cross-repository CI secret.

For a trusted main release, maintainers can run the same workflow on temporary Linux x64 self-hosted runners labeled `velocity-agent-release`: `gh workflow run agent.yml --ref main -f runner=self-hosted`. Repository administrators must register the runners, keep them available for the package job and both Node installation jobs, and remove their registration and work directories afterward. Ephemeral runners accept one job each. PRs, pushes and dispatches of other refs always use GitHub-hosted runners. Both routes require every check and the verified artifact to succeed before relaying a release; this option does not change account billing or publish a locally built package.

Version 0.5 adds multiple workspace consent. Sign in again to expand an existing single-workspace grant; refresh never adds access automatically. Removed memberships stop working immediately.

Sign in to Velocity and select every workspace you want to authorize in your browser:

```sh
velocity-agent login
velocity-agent whoami
velocity-agent status
```

Login opens a browser and listens on an ephemeral 127.0.0.1 port. If the browser cannot reach that port, paste the full redirected URL into the terminal. For SSH, containers, or a browser on another machine, use `velocity-agent login --no-browser` and paste the value shown on Velocity's code page. SSH sessions automatically use this flow. Terminal input is hidden, and login expires after five minutes.

Saved credentials authorize exactly the selected workspace set. `run` and `status` process all currently authorized workspaces by default; `--workspace <id-or-slug>` focuses on one. They use saved sign-ins without a key, refresh automatically, and serialize refresh across CLI processes. Tokens are stored per server origin in `$XDG_CONFIG_HOME/velocity/credentials.json` (default `~/.config/velocity/credentials.json`) with mode 0600. `velocity-agent logout` revokes that server's grant and removes its entry; other server entries are preserved. Use the same `--base-url` for login, run, whoami, and logout on another instance.

Concurrent commands retry if a credential-lock owner releases or replaces its
lock during the ownership check. A genuinely abandoned credential lock requires
explicit recovery: close other Velocity commands, remove only the lock path
shown in the error, then retry. Locks are never reclaimed automatically.

For automation, create a workspace token in **Settings → MCP**, with `mcp:read` and `mcp:write`, and set `VELOCITY_MCP_TOKEN` privately. The legacy `VELOCITY_API_KEY` variable also works. An explicit key takes precedence over browser credentials. `--workspace` or `VELOCITY_WORKSPACE` is optional; if supplied it must be among the currently authorized workspaces. Keep tokens out of repository files.

## Link a repository once

First configure an unambiguous **Repo → Team** or **Repo → Project** mapping under **Settings → Integrations → GitHub**. A project mapping takes precedence. Then authenticate and link its local checkout:

```sh
velocity-agent repo link --workspace your-workspace --team YOUR_TEAM --repo /path/to/repository
velocity-agent repo list --workspace your-workspace
velocity-agent run --agent codex --team YOUR_TEAM --workspace your-workspace
# Or: velocity-agent run --executor claude-code --team YOUR_TEAM --workspace your-workspace
```

Add `--project PROJECT_UUID` when linking a project-specific repository. The link command verifies workspace/team/project access, the server's current GitHub mapping and default branch, the local `origin` identity and local Git fetch access. It does not switch branches or stash/reset your changes. Native workers recheck the mapping before claim and delivery; a moved issue or remapped repository requires relinking. Git diagnostics and credentials are never copied to Velocity.

Links are local, private and scoped to server/workspace/team/project in `$XDG_CONFIG_HOME/velocity/agent-repositories.json`. A multi-workspace worker resolves each issue separately; it does not reuse another workspace's checkout. `--repo` is an explicit checkout override; Ordinary GitHub checkouts must still match the issue mapping. LandingBoost fixes use their separately verified page/repository grant; an explicit `--repo` may select that approved page checkout even when the general GitHub mapping points elsewhere. A local repository without a GitHub origin can be used explicitly for local work, with delivery disabled.

Ordinary linking leaves repository instructions untouched. Add `--write-context` only when you want the setup command to append the verified workspace context to `VELOCITY.md` and a small reference to `AGENTS.md`. Existing text is preserved and repeated matching setup adds no duplicate section. Links, context and task manifests contain no provider keys or account tokens.

## Task worktrees and recovery

Worker 0.5.5 uses writable worktrees by default. Code lives under `$XDG_DATA_HOME/velocity-agent/worktrees` (default `~/.local/share/velocity-agent/worktrees`), outside protected Git metadata. The original Git common directory holds the ownership manifests and task locks in `velocity-agent-tasks`. Each manifest binds server, workspace, issue and run to the repository identity, branch, base commit and exact path. GitHub branch templates are reused with a unique task suffix. Worktrees start from the verified repository default-branch commit; explicit local-only repositories start from HEAD. Install project dependencies in the task checkout when needed; dependencies and private environment files are not copied automatically.

A failed or interrupted task keeps its branch, commits and diff. The source checkout stays on its original branch. A new execution of the same run resumes that owned worktree; it does not reset or replace it. Requeue/retry the failed run in Velocity before restarting a worker. List saved task identities first:

```sh
velocity-agent repo tasks --workspace your-workspace --repo /path/to/repository
velocity-agent repo recover --workspace your-workspace --repo /path/to/repository --issue ISSUE_UUID --run RUN_UUID
velocity-agent repo cleanup --workspace your-workspace --repo /path/to/repository --issue ISSUE_UUID --run RUN_UUID
```

Use `recover` only after stopping the worker. It checks that the recorded PID is dead and releases only that same task lock; live, replaced or invalid locks are refused. `cleanup` removes only a clean inactive registered worktree with matching ownership. Modified, untracked or ignored files and foreign paths/branches are refused. Preserve such files yourself before cleanup. Branches and commits remain for review/recovery; cleanup never force-removes or deletes a branch. An explicitly selected `--single-checkout` keeps the older writable-checkout mode, requires a clean source and serializes workers with the common `.git/velocity-agent.lock`. Never remove that lock until its worker is confirmed stopped. Keep `XDG_DATA_HOME` consistent for task resume/cleanup.

## Shared workspace controls

Worker 0.5.7 reads **Settings → Agents → Loops** at startup and immediately before each claim. Emergency stop and a different provider or hosted execution preference leave this local worker waiting, without claiming or failing queued work. Disabling shared controls preserves the existing provider configuration; it does not requeue stopped runs. The runner never switches providers, models or billing methods automatically.

Each authorized workspace has a separate settings snapshot and journal cursor. The host checks committed policy invalidations at five-second heartbeat/safe boundaries, rereads after an expired cursor or journal failure, and refreshes settings at least every 30 seconds while polling. The queue interval is capped at 30 seconds; requests have a 10-second deadline. Unreadable, revoked or incompatible controls stop new work; an active task is interrupted and its changes remain available for recovery. Before commit, delivery or a final result, controls are read again. The server still enforces current scope, concurrency, integration permissions and cancellation atomically.

The configured server must support `get_agent_loop_settings`. An older server without it cannot authorize new work with this worker; update the server. Maintenance calls stay in the host and do not expose settings updates or the event journal as model tools. Existing repository links, native model/effort defaults and delivery authorization remain separate. This refresh does not register live sessions or automatically schedule unassigned issues.

## Codex worker

Enable Codex under **Settings → Integrations → Codex**, then assign an issue to Codex or mention `@codex` in a comment. Sign in with `codex login`, or privately set your own `CODEX_API_KEY`.

```sh
velocity-agent status --agent codex --team YOUR_TEAM
velocity-agent run --agent codex --repo /path/to/repository --team YOUR_TEAM
```

The worker only claims Codex issue runs in the selected team and authorized workspaces. Add `--workspace your-workspace` to focus on one; without it, each approved workspace is polled in turn. Use a writable Git checkout with an initial commit and configured Git author. The default creates an owned writable worktree and task branch without changing the source checkout or its tracked, untracked or ignored files. Retried runs resume their saved branch and recoverable diff. Codex uses `workspace-write` with Velocity MCP tools and tests and edits code there. Issue text and comments are untrusted task data. The runner commits successful changes and links their real SHAs, then posts the final result as the Codex virtual member. Failed or stopped attempts cannot post a success result.

Commits stay local by default. `--allow-delivery` authorizes the runner to push its branch and open a linked PR; it needs local Git authentication and Velocity's GitHub repository mapping. The runner does not merge or mark the issue Done. Native execution is unattended, bounded to 30 minutes and renews its lease; stale recovery fails abandoned work. Velocity's optional action checkpoint is unsupported for native workers and off by default.

Codex uses your own account and configured model/effort, without Velocity AI metering. `--model` and `--effort` are optional explicit overrides; omit both to preserve native defaults. `VELOCITY_CODEX_BIN` can select an installed compatible Codex binary. The package includes the Codex SDK's native runtime. One runner executes one task at a time; independent runners use separate owned worktrees. See recovery below for interrupted tasks.

Worker 0.5.8 checks an explicit Codex override against that exact execution
runtime's catalog before claiming a run or changing a checkout. An omitted
model or effort comes from the selected repository's native configuration (or
the runtime's default when unconfigured). The verified pair and provider carry
into the task worktree; the worker never silently changes to a different pair.
Unsupported choices or unavailable metadata leave queued work pending. Correct
the flags/native configuration and restart, or remove both overrides to use the
existing native default behavior.

```sh
velocity-agent codex models --repo /path/to/repository
```

This local command needs no Velocity sign-in and starts no thread or inference.
It displays model/effort/default metadata only, with `entitlementVerified: false`.
The runtime catalog may be cached and is not proof that your account can use a
model. Normal execution still handles provider authentication and access errors.
Catalog reads time out after 15 seconds and honor cancellation; older or custom
Codex binaries must support the read-only app-server config/model methods. The
0.5.11 candidate also resolves and pins default choices through this metadata
check, so removing overrides does not bypass an unavailable catalog.

## Claude Code worker

Install Claude Code, then sign in with `claude auth login`. The worker starts the installed CLI using its existing authentication; it does not obtain or proxy Claude subscription credentials.

```sh
VELOCITY_WORKSPACE=your-workspace velocity-agent run \
  --executor claude-code --repo /path/to/repository --team YOUR_TEAM
```

Enable Claude Code execution and select it as the desired execution method in Velocity. The worker only selects pending issue runs for the specified team and workspace. It uses an owned writable worktree for each task, edits and runs checks there, and preserves the source checkout. The runner commits any remaining task edits, links the actual SHAs, and handles authorized delivery after rechecking the server lease and repository mapping. Without `--allow-delivery`, commits remain local. Add `--allow-delivery` to authorize pushing and opening a PR. Git/GitHub authentication must be available locally for delivery.

Native Claude Code does not implement Velocity's optional approval checkpoint. A workspace that requires that checkpoint cannot dispatch work to this worker; use the API executor for that policy. No checkpoint is required by default.

Worker 0.5.10 validates explicit `--model` and `--effort` choices before Git
fetches, claims or checkout changes. A listed alias resolves to one model ID,
and the same native executable, resolved model and optional effort are used for
execution and result attribution. Claude effort overrides require an explicit
model so the worker can verify the pair; omit both flags to retain native
configured defaults. Invalid choices, unavailable/old metadata and cancellation
leave work pending. Correct the flags or upgrade Claude Code and retry.
Advertised long-context suffixes such as `[1m]` are retained when resolving an alias.

```sh
velocity-agent claude models --repo /path/to/repository
velocity-agent run --executor claude-code --team YOUR_TEAM --model LISTED_MODEL --effort high
```

The local catalog command requires no Velocity sign-in and sends no user prompt
or inference request. It uses Claude Code's metadata-only SDK initialize
exchange, safe mode, disabled tools/hooks/MCP and no persistent session. Only
model IDs and supported efforts are displayed, with `entitlementVerified: false`;
account details and raw runtime diagnostics are discarded. The read has a
15-second deadline and honors cancellation. Catalog compatibility does not
guarantee provider access or quota. `VELOCITY_CLAUDE_BIN` selects the native
executable; otherwise it is resolved from PATH. Custom/older runtimes must
support safe-mode initialization with resolved model metadata to use overrides.

## LandingBoost fixes

Mapped LandingBoost fixes require the 0.5.3 worker (or later) with its approved GitHub checkout. The public installation above supports these tasks; older workers leave them pending.

In Velocity's LandingBoost settings, map the exact page, its approved `org/repo`, and Claude Code or Codex. Enable assignment events for that native agent. With **Manual handoff**, load delivery status and choose **Queue agent fix** for a current ready finding; automatic work can remain off. To start fixes as callbacks arrive, choose **Queue a native agent** and also enable automatic work. Saved plans that need input or review and monitoring notifications do not schedule fixes. Ordinary issue assignment remains available.

The worker verifies `origin` against the page grant before claiming a task or editing and uses an owned writable worktree. Its local Git sign-in reads the approved repository’s default branch; a generic issue mapping does not override the page grant. An explicit `--repo` can select the approved checkout, or an unambiguous saved link for that repository can be reused. `--allow-delivery` requires the workspace GitHub issue mapping to match the approved page repository before any host push/PR; a mismatch preserves local commits and reports the needed correction. Existing source-checkout changes are preserved. The platform rechecks the latest saved report at claim and stops revoked connections, mappings or permissions; manual handoff also requires the initiating person's current workspace admin access. Repeated findings reuse one run across manual clicks, callback retries and reconnects. Inspect the linked issue for actual checks, commits and proposed changes, and the LandingBoost delivery panel for run status. A failed fix can explicitly retry the same run twice; retries do not start new scans or deploy changes.

## Native usage and cost

Worker 0.5.15 records native model usage separately from Velocity
AI credits. Requires the native usage server/migration. Codex now
resolves and pins inherited native defaults before claiming work. Claude Code
captures resolved models from terminal telemetry when supported. Run details
label API-equivalent estimates, actual reported charges and unavailable data;
subscription estimates do not imply an additional invoice or marginal charge.
See [native usage and pricing coverage](https://docs.velocity.quest/integrations/codex).

## Anthropic API worker

Set your `ANTHROPIC_API_KEY` and enable Local API execution in Velocity:

```sh
VELOCITY_WORKSPACE=your-workspace velocity-agent run --executor anthropic
```

Worker 0.5.9 verifies the configured model through the same API client before claiming a run. A valid alias resolves to one model ID used for every turn and the run result; each subsequent attempt checks again. Invalid models, unavailable metadata, missing credentials and cancellation leave queued work pending. The metadata check has a ten-second deadline with no automatic retry and does not run inference or guarantee remaining credits. Use `--model MODEL_ID` to select an available model; the worker never falls back to another model. Idle polling, status and native workers do not make this API check.

This method calls the Anthropic API and uses API billing. It is not Claude Code subscription execution. Your Anthropic key stays on your machine.

## PRDs and user stories

Worker 0.5.4 adds PRD, requirement and user-story context and manual planning operations to Claude Code and Codex. The configured Velocity server must provide the planning MCP tools. Only operator-selected changes should be applied; PRD approval always remains with a human.

The API executor discovers its issue and planning schemas through authenticated `tools/list` for the current workspace and execution. It does not carry a separate copy of the server schemas or grant account administration/deletion tools. Discovery has a 10-second deadline, a 1 MB response limit and a bounded, two-minute in-memory cache scoped to the exact claim. An older server without planning tools can still provide ordinary issue tools; a missing or malformed catalogue fails the run before a model request.

The API executor can also request metered planning proposals. It presents generated proposals for human review and cannot apply them in the same execution, including by creating an ordinary issue. Apply the selected changes in a subsequent explicitly requested manual run. Cost estimates alone do not create proposals. Native workers expose manual planning tools, without enabling the platform's AI proposal tools. Planning writes remain subject to current role/scope, run policy, emergency stop and server validation; restricted automation and source-bound LandingBoost fixes cannot use them to expand their scope. Platform AI plan, credit and budget rules remain in force.

Use `--base-url https://your-velocity-instance.example` for a different server, `--once` for one batch, and `velocity-agent run --help` for all options. `velocity-agent status` reports pending local API runs; it does not prove that a native worker is online. Enable a worker only for repositories and team work you authorize it to process.

### Console verbosity

Set `velocity-agent run --verbosity QUIET|NORMAL|FULL` or
`VELOCITY_AGENT_VERBOSITY`. Values are case-insensitive; the command-line option
overrides the environment variable. Invalid values stop startup.

| Level | Console output |
| --- | --- |
| `QUIET` | Warnings and errors only. |
| `NORMAL` (default) | Work-start notices after a successful claim, progress, issue comment/status actions and outcomes. Messages omit issue content, model text, tool arguments/results, workspace names, local paths and raw errors. |
| `FULL` | All available execution events, including model text, prompts, commands/output, tool inputs/results, native diagnostics and runner activity. |

```sh
velocity-agent run --agent codex --team YOUR_TEAM --verbosity FULL
VELOCITY_AGENT_VERBOSITY=QUIET velocity-agent run --executor claude-code --team YOUR_TEAM
```

The level applies to the runner, Codex, Claude Code, API execution and live
progress output, including `--once`. It controls worker activity logs; commands
such as `login`, `status` and `repo list` retain their requested output.
`FULL` is a local diagnostic view and can display sensitive issue and repository
material. Authentication headers and credential configuration are not logged;
known worker/environment credentials and structured credential fields are
redacted. This is not a general-purpose secret scanner for arbitrary file or
command output. Detailed console activity is never sent as progress telemetry:
all levels publish the same fixed progress codes to Velocity.


Shared execution controls require worker 0.5.7 or later. **Require isolated worktrees** keeps workers with `--single-checkout` and API-only workers idle. **Local changes only** overrides `--allow-delivery`: the host keeps and links local commits without pushing or opening a PR. Existing delivery permissions still require local `--allow-delivery`; shared settings never grant it. Controls refresh before delivery, and restrictions changing in flight preserve your local changes. Delivery eligibility can only narrow during a run; lifting local-only controls applies to a subsequent attempt after fresh repository verification. Older workers cannot claim work while these restrictions are active. Private draft preferences are not activated by upgrading.

### Live run progress

Upgraded workers publish safe activity to the terminal and the run detail page
through `append_agent_run_events`. Deploy the run-progress migration and API
before installing the upgraded worker. Older servers show a telemetry warning;
execution and existing lease/stop checks continue. The detail page refreshes
automatically while visible, resumes from its last event cursor after a network
failure, and can load earlier pages. It retains the latest 2,000 events per run.
A worker restart uses a new execution lease; previously recorded history remains.

Progress includes checkout preparation, SDK activity, tools, recognized validation
commands, commits, delivery and the server-recorded terminal outcome. Native Codex
provides command exit status. Claude Code reports tool boundaries; validation
results without an explicit exit status say so. The API executor reports turn and
tool boundaries. Persisted progress and the default console output omit unknown
SDK event types, raw commands, output, arguments and private reasoning; `FULL`
console output includes available execution events. CI/review/deployment waits require an executor to
report them explicitly; opening a PR does not mean those steps completed.

Last worker contact is independent of activity. A quiet connected task can still
be working; contact older than 30 seconds is shown as stale. Execution completion,
worker completion and delivery are displayed separately. Delivery remains local
unless authorized by the operator and workspace controls. A dropped telemetry
response is retried with the same sequence; a partial outage keeps prior history
and buffers up to 2,000 pending events in memory. Unsent events can be lost when a
worker process exits during an outage; accepted events survive refresh/reconnect.


### Configured delivery (0.5.12)

Run a native worker with `--workflow /absolute/path/workflow.json`. Keep the file
private (`chmod 600`); commands come from the operator, never issue prose.
Existing local-only behavior and the legacy `--allow-delivery` PR handoff remain
available. Choose one option. Example for a repository whose tests are `pnpm test`:

```json
{
  "version": 1,
  "policy": {
    "mode": "merge",
    "validationRequired": true,
    "deploymentRequired": false,
    "maxRepairAttempts": 1
  },
  "checks": [{ "name": "Repository tests", "argv": ["pnpm", "test"] }]
}
```

Modes `local` and `pr` produce explicit handoffs without marking the issue Done.
Modes `merge` and `deploy` require workspace owner/admin access. Protected workspace
limits, current membership/grants, mapping, approval settings and emergency stop
remain authoritative. Validation is bound to the exact Git tree, including new
files. Required checks cannot be skipped. For an intentional low-impact skip,
set `validationRequired: false` and a meaningful `skipValidationReason`.
Commands execute without a shell; pass credentials through the environment,
never argument values. Outcomes, command identities and source SHAs are recorded.

A deployment requirement needs `mode: "deploy"`, `deploymentRequired: true` and
`deployment: { "deploy": ["your-release-script"], "verify": ["your-acceptance-script"] }`.
Both adapters receive `VELOCITY_DELIVERY_SOURCE_SHA` containing the confirmed
merge SHA. Deploy prints a single JSON receipt `{ "sourceSha": "...", "artifactId":
"...", "url": "https://..." }`; diagnostics go to stderr. Verify receives the
receipt on stdin, verifies the actual released artifact and meaningful acceptance
checks, and prints the same identity with `"acceptancePassed": true`. No adapter,
failed acceptance, or a source mismatch means no Done. Merge-only never claims
a production deployment. Operator scripts must be idempotent for the source SHA.

CI waits persist in Velocity and in private Git metadata, release the native
turn, and resume on a later poll/restart with the same authorized account,
repository mapping and configuration. An active checkout lock cannot be stolen;
after confirming a crashed worker is stopped, use `velocity-agent repo recover`.
Jobs preserve their original stop point and commands, so editing a configuration
cannot silently upgrade an existing job. Relevant validation/CI failures may
queue 0–3 bounded native repair attempts (default 0), retaining the original
runtime deadline. Exhaustion records Blocked and preserves work. Provider outages
wait for a later poll without another coding turn. GitHub checks/reviews are
re-read on the exact PR SHA at the merge boundary, without protection bypass.

The run detail page distinguishes coding completion from validation, PR, CI,
merge, deployment and issue closure. The final evidence comment and Done transition
commit together and survive a lost response without duplication. Per-profile
central configuration and per-issue cues are separate ENGIN-594/595 work; this
version uses the explicit operator configuration above.

Stop an unfinished workflow from its run detail page (runner owner or workspace
administrator), even after the coding turn has completed. This records Blocked
and preserves code. A single checkout stays reserved for its pending delivery;
only its queued repair may resume until the workflow hands off or finishes.
