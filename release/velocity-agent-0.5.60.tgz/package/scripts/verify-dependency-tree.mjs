// The reviewed dependency tree of a velocity-agent archive (ENGIN-693).
// pack-release.mjs bundles the exact portable packages product CI tested and
// records them in dependency-tree.json; platform runtime packages stay exact
// optional dependencies so npm still selects the host's binary. Product and
// public distribution CI verify an installation against that record. Node
// built-ins only: the distribution repository runs this file as copied.
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { readdir, readFile } from 'node:fs/promises';
import { basename, dirname, join, relative, sep } from 'node:path';

export const TREE_FILE = 'dependency-tree.json';
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const PATH = /^node_modules\/(?:@[a-z0-9][\w.-]*\/)?[a-z0-9][\w.-]*(?:\/node_modules\/(?:@[a-z0-9][\w.-]*\/)?[a-z0-9][\w.-]*)*$/i;
const NAME = /^(?:@[a-z0-9][\w.-]*\/)?[a-z0-9][\w.-]*$/i;
const VERSION = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/;
const INTEGRITY = /^sha512-[A-Za-z0-9+/]{86}==$/;

/** Files a package directory ships itself; nested node_modules belong to other packages. */
export async function packageFiles(directory, prefix = '') {
  const files = [];
  for (const entry of await readdir(join(directory, prefix), { withFileTypes: true })) {
    const path = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) { if (entry.name !== 'node_modules') files.push(...await packageFiles(directory, path)); }
    else if (entry.isFile()) files.push(path);
    else throw new Error(`Package entry ${join(directory, path)} is not a regular file`);
  }
  return files;
}

/** Content identity of one package: every shipped file path and its bytes. */
export async function contentsDigest(directory, files) {
  const lines = [];
  for (const file of [...(files ?? await packageFiles(directory))].sort())
    lines.push(`${file}\0${sha256(await readFile(join(directory, ...file.split('/'))))}\n`);
  return sha256(lines.join(''));
}

/** Throw unless the parsed record has the exact shape pack-release.mjs writes. */
export function checkTreeShape(tree) {
  const record = value => value && typeof value === 'object' && !Array.isArray(value);
  const list = value => value === undefined || (Array.isArray(value) && value.length > 0 && value.every(item => typeof item === 'string' && /^!?[\w-]+$/.test(item)));
  const fail = what => { throw new Error(`Invalid ${TREE_FILE}: ${what}`); };
  if (!record(tree) || tree.schemaVersion !== 1 || tree.name !== 'velocity-agent' || !VERSION.test(tree.version ?? '')) fail('header');
  for (const key of ['dependencies', 'optionalDependencies', 'packages']) if (!record(tree[key])) fail(key);
  const edges = (owner, deps) => {
    if (!record(deps)) fail(`${owner} dependencies`);
    for (const [name, path] of Object.entries(deps)) {
      const named = path === 'node_modules/' + name || path.endsWith('/node_modules/' + name);
      if (!NAME.test(name) || !Object.hasOwn(tree.packages, path) || !named) fail(`${owner} -> ${name}`);
    }
  };
  for (const [path, entry] of Object.entries(tree.packages)) {
    if (!PATH.test(path) || !record(entry) || !NAME.test(entry.name ?? '') || !VERSION.test(entry.version ?? '') || !INTEGRITY.test(entry.integrity ?? '') || !/^[a-f0-9]{64}$/.test(entry.contents ?? '') || (entry.patched !== undefined && entry.patched !== true)) fail(path);
    edges(path, entry.dependencies);
    if (entry.optionalDependencies !== undefined) {
      if (!record(entry.optionalDependencies)) fail(`${path} optionalDependencies`);
      for (const [name, spec] of Object.entries(entry.optionalDependencies)) if (tree.optionalDependencies[name]?.spec !== spec) fail(`${path} -> ${name}`);
    }
  }
  edges('velocity-agent', tree.dependencies);
  for (const [name, entry] of Object.entries(tree.optionalDependencies))
    if (!NAME.test(name) || !record(entry) || typeof entry.spec !== 'string' || !NAME.test(entry.name ?? '') || !VERSION.test(entry.version ?? '') || !INTEGRITY.test(entry.integrity ?? '') || !list(entry.os) || !list(entry.cpu) || !list(entry.libc)) fail(name);
  return tree;
}

// npm-install-checks semantics: a list matches a value unless it excludes it.
const allows = (list, value) => {
  if (!list) return true;
  let negated = 0, match = false;
  for (const item of list) {
    if (item.startsWith('!')) { negated++; if (item.slice(1) === value) return false; }
    else match ||= item === value;
  }
  return match || negated === list.length;
};
export function hostPlatform() {
  const libc = process.platform !== 'linux' ? undefined : process.report?.getReport?.().header?.glibcVersionRuntime ? 'glibc' : 'musl';
  return { os: process.platform, cpu: process.arch, libc };
}
const applies = (entry, platform) => allows(entry.os, platform.os) && allows(entry.cpu, platform.cpu) && (!entry.libc || !platform.libc || allows(entry.libc, platform.libc));

// Node's lookup from a package directory: each ancestor's node_modules, nearest first.
function lookup(from, name) {
  for (let directory = from; ;) {
    if (basename(directory) !== 'node_modules') {
      const candidate = join(directory, 'node_modules', ...name.split('/'));
      if (existsSync(join(candidate, 'package.json'))) return candidate;
    }
    const parent = dirname(directory);
    if (parent === directory) return null;
    directory = parent;
  }
}
async function installedPackages(nodeModules) {
  const found = [];
  if (!existsSync(nodeModules)) return found;
  for (const entry of await readdir(nodeModules, { withFileTypes: true })) {
    if (entry.name.startsWith('.')) continue;
    const scoped = entry.name.startsWith('@');
    for (const name of scoped ? (await readdir(join(nodeModules, entry.name))).map(item => join(entry.name, item)) : [entry.name]) {
      const directory = join(nodeModules, name);
      if (existsSync(join(directory, 'package.json'))) found.push(directory);
      found.push(...await installedPackages(join(directory, 'node_modules')));
    }
  }
  return found;
}

/**
 * Verify an installed velocity-agent (its package directory) against its
 * reviewed dependency tree. `digest` binds the record to release provenance;
 * `exclusive` rejects any other package in that node_modules tree;
 * `requireIntegrity` requires npm's install record for platform packages.
 */
export async function verifyDependencyTree(packageDir, { digest, exclusive = false, requireIntegrity = false, platform = hostPlatform() } = {}) {
  const bytes = await readFile(join(packageDir, TREE_FILE));
  const identity = sha256(bytes);
  if (digest !== undefined && identity !== digest) throw new Error(`Installed dependency tree ${identity} is not the reviewed tree ${digest}`);
  const tree = checkTreeShape(JSON.parse(bytes.toString('utf8')));
  const at = path => path ? join(packageDir, ...path.split('/')) : packageDir;
  const installRoot = dirname(dirname(packageDir));
  const label = directory => relative(installRoot, directory).split(sep).join('/');
  const failures = [];
  const manifest = JSON.parse(await readFile(join(packageDir, 'package.json'), 'utf8'));
  if (manifest.version !== tree.version) failures.push(`${TREE_FILE} describes ${tree.version}, installed ${manifest.version}`);
  for (const [path, entry] of Object.entries(tree.packages)) {
    let installed;
    try { installed = JSON.parse(await readFile(join(at(path), 'package.json'), 'utf8')); } catch { failures.push(`${path} is missing`); continue; }
    if (installed.name !== entry.name || installed.version !== entry.version) failures.push(`${path} is ${installed.name}@${installed.version}, not the reviewed ${entry.name}@${entry.version}`);
    else if (await contentsDigest(at(path)) !== entry.contents) failures.push(`${path} differs from the reviewed ${entry.name}@${entry.version}`);
  }
  for (const [from, deps] of [['', tree.dependencies], ...Object.entries(tree.packages).map(([path, entry]) => [path, entry.dependencies])])
    for (const [name, to] of Object.entries(deps)) {
      const found = lookup(at(from), name);
      if (found !== at(to)) failures.push(`${from || 'velocity-agent'} resolves ${name} to ${found ? label(found) : 'nothing'}, not ${to}`);
    }
  let record = null;
  try { record = JSON.parse(await readFile(join(dirname(packageDir), '.package-lock.json'), 'utf8')); } catch { /* checked below when required */ }
  if (requireIntegrity && !record) failures.push('npm did not write its install record (node_modules/.package-lock.json)');
  const runtime = new Set();
  const groups = [['', manifest.optionalDependencies ?? {}], ...Object.entries(tree.packages).filter(([, entry]) => entry.optionalDependencies).map(([path, entry]) => [path, entry.optionalDependencies])];
  for (const [from, specs] of groups) {
    let hostPackages = 0, hostInstalled = 0;
    for (const name of Object.keys(specs)) {
      const entry = tree.optionalDependencies[name];
      if (!entry) { failures.push(`${from || 'velocity-agent'} declares unreviewed optional ${name}`); continue; }
      if (applies(entry, platform)) hostPackages++;
      const found = lookup(at(from), name);
      if (!found) continue;
      if (applies(entry, platform)) hostInstalled++;
      runtime.add(found);
      const installed = JSON.parse(await readFile(join(found, 'package.json'), 'utf8'));
      if (installed.name !== entry.name || installed.version !== entry.version) failures.push(`${label(found)} is ${installed.name}@${installed.version}, not the reviewed ${entry.name}@${entry.version}`);
      const recorded = record?.packages?.[label(found)];
      if (record && recorded?.integrity !== entry.integrity) failures.push(`${label(found)} was installed with integrity ${recorded?.integrity ?? 'unknown'}, not the reviewed ${entry.integrity}`);
    }
    if (from && hostPackages > 0 && hostInstalled === 0) failures.push(`No ${platform.os}-${platform.cpu} runtime package is installed for ${from}`);
  }
  if (exclusive) {
    const expected = new Set([packageDir, ...Object.keys(tree.packages).map(at), ...runtime]);
    for (const directory of await installedPackages(dirname(packageDir)))
      if (!expected.has(directory)) failures.push(`Unreviewed package installed at ${label(directory)}`);
  }
  if (failures.length) throw new Error(`Installed velocity-agent does not match its reviewed dependency tree ${identity}:\n- ${failures.slice(0, 20).join('\n- ')}`);
  return { digest: identity, packages: Object.keys(tree.packages).length, runtime: [...runtime].map(label).sort() };
}
